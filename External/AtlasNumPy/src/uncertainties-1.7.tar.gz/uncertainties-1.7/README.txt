To install:

   python setup.py install
or
   sudo python setup.py install  # if you need additional access rights
or
   python setup.py install --prefix my_directory  # install in my_directory
or
   simply copy the uncertainties/ directory to a location that Python 
   can import from (directory in which scripts using uncertainties are 
   run, etc.).
