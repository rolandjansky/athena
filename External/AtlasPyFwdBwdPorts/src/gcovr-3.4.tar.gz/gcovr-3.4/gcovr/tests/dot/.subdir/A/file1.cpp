int foo(int param)
{
  if (param) {
     return 1;
  } else {
     return 0;
  }
}
