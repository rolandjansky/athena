# @file setup.py
# @purpose: build some backported python modules from 2.6
#           modelled after the setup.py from python-multiprocessing

__version__ = "$Revision: 1.1 $"

import os
import sys
import glob

from distutils.core import setup

# Python.version.number.internal_revision
VERSION='2.6.1.0'

HERE = os.path.dirname(os.path.abspath(__file__))

from distutils.core import setup
setup(name='abc',
      version=VERSION,
      package_dir={'': 'Lib'},
      packages=[''],
      )
