# -*- coding: utf8 -*-
from extensions import dist

from extensions.registry import register, register_file
from extensions.reader import get_plugins as get

