from distutils.core import setup
import foo

setup(name='foo', version='0.1',
      packages=['foo'])

