Descriptions of Examples
------------------------

grin, grind :
    Scripts that avoid the pkg_resources startup overhead.

grinimports.py :
    Tool that will take Python files, extract all of their import statements,
    normalize the import statements, and grep for the given regex on those
    normalized statements. See "grinimports.py --help" for more information.
