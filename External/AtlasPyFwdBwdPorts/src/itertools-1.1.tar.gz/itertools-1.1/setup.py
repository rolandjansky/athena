# @file setup.py
# @purpose: build some backported python modules from 2.6
#           modelled after the setup.py from python-multiprocessing

__version__ = "$Revision: 1.1 $"

import os
import sys
import glob

from distutils.core import setup, Extension

# Python.version.number.internal_revision
VERSION='2.6.1.0'

HERE = os.path.dirname(os.path.abspath(__file__))

# check __version__ in release mode
if len(sys.argv) > 1 and "dist" in sys.argv[1]:
    mp = os.path.join(HERE, "Lib", "__init__.py")
    for line in open(mp):
        if line.startswith("__version__"):
            expected = "__version__ = '%s'" % VERSION
            if line.strip() != expected:
                raise ValueError("Version line in %s is wrong: %s\n"
                                 "expected: %s" % 
                                 (mp, line.strip(), expected))
            break


if sys.version_info < (2, 4):
    raise ValueError("Versions of Python before 2.4 are not supported")

itertools_srcs = ['Modules/itertoolsmodule.c']

extensions = [
    Extension('itertools',
              sources=itertools_srcs,
              ),
    ]

if sys.version_info >= (2, 6):
    # no need to build !
    raise ValueError(
        'python [%s] already has a proper \'itertools\' module'%str(sys.version_info)
        )

packages = [
    'itertools',
    #'itertools.tests',
    ]

package_dir = {
    'itertools': 'Lib',
    }

long_description = "<some description>"

setup(
    name='itertools',
    version=VERSION,
    description=('Backport of the itertools package to '
                 'Python 2.5'),
    long_description=long_description,
    packages=packages,
    package_dir=package_dir,
    ext_modules=extensions,
    author='Python Software Foundation',
    author_email='python-dev@python.org',
    maintainer='Sebastien Binet',
    maintainer_email='binet at cern dot ch',
    download_url='http://pypi.python.org/pypi',
    url='http://python.org',
    license='BSD Licence',
    platforms='Unix and Windows',
    #test_suite="itertools.tests",
    keywords="",
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Programming Language :: Python',
        'Programming Language :: C',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: POSIX',
        'License :: OSI Approved :: BSD License',
        'Topic :: Software Development :: Libraries :: Python Modules',
        ]
    )

