
/* seb: hack for py-2.5 */
#ifndef Py_TYPE
#define Py_TYPE(ob)            (((PyObject*)(ob))->ob_type)
#endif

#ifndef PyObject_HEAD_INIT
#define PyObject_HEAD_INIT(type)        \
        _PyObject_EXTRA_INIT            \
        1, type,
#endif

#ifndef PyVarObject_HEAD_INIT
#define PyVarObject_HEAD_INIT(type, size)       \
        PyObject_HEAD_INIT(type) size,
#endif

#ifndef Py_REFCNT
#define Py_REFCNT(ob)          (((PyObject*)(ob))->ob_refcnt)
#endif

PyAPI_FUNC(long) PyObject_HashNotImplemented(PyObject *);
long
PyObject_HashNotImplemented(PyObject *self)
{
	PyErr_Format(PyExc_TypeError, "unhashable type: '%.200s'",
		     self->ob_type->tp_name);
	return -1;
}
