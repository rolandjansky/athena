-----
hgsvn
-----

To read the documentation, either type `pydoc hgsvn`,
or go to the following Web page:
http://pypi.python.org/pypi/hgsvn
