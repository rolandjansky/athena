# This stub is used by py2exe
from hgsvn.run.hgpushsvn import main

main()
