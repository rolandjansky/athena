# This stub is used by py2exe
from hgsvn.run.hgpullsvn import main

main()
