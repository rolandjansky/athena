# This stub is used by py2exe
from hgsvn.run.hgimportsvn import main

main()
