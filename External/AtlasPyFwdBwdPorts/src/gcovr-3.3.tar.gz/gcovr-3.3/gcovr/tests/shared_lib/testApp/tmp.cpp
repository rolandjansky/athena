#include "lib.h"

int main(int argc, char** argv)
{
   if ( argc > 1 )
      print(1);
   else
      print(0);
}
