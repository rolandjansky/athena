int uncovered()
{
return 0;
}
