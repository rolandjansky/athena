XSLT = {
    'xml':       None,
    'csv':       'AMIXmlToCsv.xsl',
    'htmltable': 'AMIXmlToHtmlTable.xsl',
    'html':      'AMIXmlToHtml.xsl',
    'text':      'AMIXmlToText.xsl',
    'verbose':   'AMIXmlToTextVerbose.xsl',
}
