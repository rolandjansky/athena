
class AMI_Error_Base(Exception):
    pass


class AMI_Info(AMI_Error_Base):
    pass


class AMI_Error(AMI_Error_Base):
    pass


class AMI_Info(AMI_Error_Base):
    pass
