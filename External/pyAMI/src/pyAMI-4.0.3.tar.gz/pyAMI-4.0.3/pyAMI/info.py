"""
                _    __  __ ___
 _ __  _   _   / \  |  \/  |_ _|
| '_ \| | | | / _ \ | |\/| || |
| |_) | |_| |/ ___ \| |  | || |
| .__/ \__, /_/   \_\_|  |_|___|
|_|    |___/
                   %s
Authors:

Solveig Albrand
Noel Dawe
Jerome Fulachier
Fabian Lambert

"""

VERSION = '4.0.3'
AUTHOR_EMAIL = 'atlas-bookkeeping@cern.ch'
URL = 'https://end.web.cern.ch/end/projects/pyAMI/'
DOWNLOAD_URL = 'http://pypi.python.org/packages/source/p/pyAMI/pyAMI-%s.tar.gz' % VERSION

__doc__ %= VERSION
