Documentation can be found online:
http://packages.python.org/rootplot/
