/***************************************************************************
 Parametrization of the Dead Material Map 
 -------------------------------------------
 Copyright (C) 2003 by ATLAS Collaboration
 ***************************************************************************/

//<doc><file>	$Id: MaterialMap.h,v 1.7 2004/11/08 11:02:30 goldfarb Exp $
//<version>	$Name: MooEvent-00-01-16 $

#ifndef MOOEVENT_MATERIALMAP_H
#define MOOEVENT_MATERIALMAP_H

//<<<<<< INCLUDES                                                       >>>>>>

#include <map>
#include <fstream>
#include <iostream>
#include <string>
//use the method defined at:  http://annwm.lbl.gov/~leggett/Atlas/gcc-3.2.html
#ifdef HAVE_NEW_IOSTREAMS
  #include <sstream>
typedef std::istringstream my_isstream;

#else
  #include <strstream>
typedef strstream my_isstream;
#endif


//<<<<<< PUBLIC DEFINES                                                 >>>>>>
//<<<<<< PUBLIC CONSTANTS                                               >>>>>>
//<<<<<< PUBLIC TYPES                                                   >>>>>>
//<<<<<< PUBLIC VARIABLES                                               >>>>>>
//<<<<<< PUBLIC FUNCTIONS                                               >>>>>>
//<<<<<< CLASS DECLARATIONS                                             >>>>>>

class MaterialParameters;

typedef enum iost {READ, WRITE} IOMaterialMap;


class MaterialMap{
public:
  static MaterialMap * getMaterialMap(std::string fileName, IOMaterialMap io=READ);
  bool insertElement(int, int, int, MaterialParameters);
  ~MaterialMap();
  bool writeMap();
  void printMap();
  int NbEvents(int, int, int);
  double Thickness(int, int, int);
  double SigmaThickness(int, int, int);
  double EnergyLoss0(int, int, int);
  double EnergyLoss1(int, int, int);
  double SigmaELoss0(int, int, int);
  double SigmaELoss1(int, int, int);

  // methods to retrive the bins given cot(theta) and phi
  int get_cotth_bin(double cot_theta, int jphi) const;
  int get_phi_bin(double phi) const;
  int get_phi_bin(double phi, int& jphi) const;
  int get_map_bins(double phi, double ctheta, int& iphi, int& ictheta) const;      
  int get_map_bins(double phi, double ctheta, int& iphi, int& jphi, int& ictheta) const;      
    
private:
  MaterialMap(std::string fileName, IOMaterialMap io=READ);
  static MaterialMap * myself;
  std::map<int, MaterialParameters > mate_map;
  bool openFileWrite(std::string);
  bool openFileRead(std::string);
  bool closeFile();
  int getKey(int, int, int);
  bool readMap();
  int getEta(int);
  int getPhi(int);
  int getRadius(int); 
  //
  static bool status_read;
  std::fstream* ioFile;
  typedef std::map<int, MaterialParameters >::const_iterator itermap;
  std::string fileToWrite;

// map binning parameters

  static const int   Bnbins_phi;
  static const int   Bnbins_cth;
  static const int   Bnbins_r;
  static const double BdphiLSect;
  static const double BdphiSSectClear;
  static const double BdphiSSectCoils;
  static const double Bphi0;
  static const double Bphi1;  
  static const double Bphi2;  
  static const double Bphi3;
  static const double Bphi4;
  static const double Bdcth;     
  static const double Br0SSect;  
  static const double Br1SSect;  
  static const double Br2SSect;  
  static const double Br0LSect;  
  static const double Br1LSect;  
  static const double Br2LSect;
  static const double BarrelL_cth_edge;
  static const double BarrelS_cth_edge;
  static const int    NsliceECL_cth;
  static const double ECL_cth_edge[6];
  static const int    NsliceECS_cth;
  static const double ECS_cth_edge[5];
};


//<<<<<< INLINE PUBLIC FUNCTIONS                                        >>>>>>
//<<<<<< INLINE MEMBER FUNCTIONS                                        >>>>>>

#endif // MOOEVENT_MATERIALMAP_H
