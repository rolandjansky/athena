#ifndef MOOEVENT_MOORZSEGMENT_H
# define MOOEVENT_MOORZSEGMENT_H

#include <math.h>
#include "CLHEP/Geometry/Point3D.h"

#include "Identifier/Identifier.h"

class MuonIdHelper;

class MooRZSegment
{
public:

  MooRZSegment  (void);
  MooRZSegment  (double z, double rho, double theta);
  MooRZSegment	(const double& alpha,
		 const double& Dalpha,
		 const double& beta,
		 const double& Dbeta,
		 const double& off_diagonal,
		 const double& Chi2,
		 const int&    nDegF);
  MooRZSegment  (const MooRZSegment&); // Copy constructor

  virtual ~MooRZSegment (void);

  double   z	        (void) const;
  double   rho	        (void) const;
  double   beta         (void) const;
  double   beta_error   (void) const;
  double   theta        (void) const;
  double   theta_error  (void) const;
  double   off_diagonal (void) const;
  double   Chi2         (void) const;
  int      nDegF        (void) const;
  double   tan_theta    (void) const;
  double   cot_theta    (void) const;
  double   cos_theta    (void) const;

  void   z	      (double);
  void   rho	      (double);
  void   beta         (double);
  void   beta_error   (double);
  void   theta        (double);
  void   theta_error  (double);
  void   off_diagonal (double);
  void   Chi2         (double);
  void   nDegF        (int);
  void   tan_theta    (double);
  void   cot_theta    (double);

  const Identifier             identify_module   (void) const;

  virtual  const HepPoint3D&   detector_position  (void) const;

  virtual unsigned  hits_count	     (void) const;
  
protected:

  double	m_z;
  double	m_rho;
  double	m_beta;
  double	m_beta_error;
  double	m_theta;
  double	m_theta_error;
  double        m_off_diagonal;
  double        m_Chi2;
  int           m_nDegF;
  double	m_tan_theta;
  double	m_cot_theta;
  Identifier    m_moduleID;
};

inline double
MooRZSegment::z	(void)	const
{ return m_z; }

inline double
MooRZSegment::rho 	(void)	const
{ return m_rho; }

inline double
MooRZSegment::beta	(void)	const
{ return m_beta; }

inline double
MooRZSegment::beta_error	(void)	const
{ return m_beta_error; }

inline double
MooRZSegment::theta	(void)	const
{ return m_theta; }

inline double
MooRZSegment::theta_error	(void)	const
{ return m_theta_error; }

inline double
MooRZSegment::off_diagonal	(void)	const
{ return m_off_diagonal; }

inline double
MooRZSegment::Chi2 (void) const
{ return m_Chi2; }

inline int
MooRZSegment::nDegF       (void) const
{ return m_nDegF; }

inline double
MooRZSegment::tan_theta	(void)	const
{ return m_tan_theta; }

inline double
MooRZSegment::cot_theta	(void)	const
{ return m_cot_theta; }

inline double
MooRZSegment::cos_theta	(void)	const
{ return 1./sqrt( 1. + (m_tan_theta * m_tan_theta) ); }

inline void
MooRZSegment::z	(double value)
{ m_z = value; }

inline void
MooRZSegment::rho (double value)
{ m_rho = value; }

inline void
MooRZSegment::beta (double value)
{ m_beta = value; }

inline void
MooRZSegment::beta_error (double value)
{ m_beta_error = value; }

inline void
MooRZSegment::theta (double value)
{ m_theta = value; }

inline void
MooRZSegment::theta_error (double value)
{ m_theta_error = value; }

inline void
MooRZSegment::off_diagonal (double value)
{ m_off_diagonal = value; }

inline void
MooRZSegment::Chi2 (double value)
{ m_Chi2 = value; }

inline void
MooRZSegment::nDegF       (int value)
{ m_nDegF = value; }

inline void
MooRZSegment::tan_theta	(double value)
{ m_tan_theta = value; }

inline void
MooRZSegment::cot_theta	(double value)
{ m_cot_theta = value; }

inline const Identifier
MooRZSegment::identify_module   (void) const
{ return m_moduleID; }

#endif // MOOEVENT_MOORZSEGMENT_H












