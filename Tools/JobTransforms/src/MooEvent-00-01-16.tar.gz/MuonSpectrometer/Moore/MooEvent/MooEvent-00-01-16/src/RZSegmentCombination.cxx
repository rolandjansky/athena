#include "MooEvent/RZSegmentCombination.h"
#include "MooEvent/MooRZSegment.h"

RZSegmentCombination::RZSegmentCombination (std::vector<MooRZSegment*>& segs)
  :	m_segments     ( 0 ),
	m_hits_count   ( 0 ),
	m_min_theta    ( 10. ),
	m_max_theta    ( -10. )
{
  for (std::vector<MooRZSegment*>::const_iterator s = segs.begin(); s != segs.end(); ++s) {
    m_segments.push_back(*s);
    m_hits_count += (*s)->hits_count();
    m_min_theta = std::min((*s)->theta(), m_min_theta);
    m_max_theta = std::max((*s)->theta(), m_max_theta);
  }
}
