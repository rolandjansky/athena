#ifndef MOOEVENT_MOOROADCONTAINER_H
# define MOOEVENT_MOOROADCONTAINER_H

#include "DataModel/DataVector.h"
#include "CLIDSvc/CLASS_DEF.h"
#include "MooEvent/MooiPatTrack.h"

class MooRoadContainer: public DataVector<MooiPatTrack>
{
public:
  MooRoadContainer (void);
  ~MooRoadContainer (void);
};

inline
MooRoadContainer::MooRoadContainer (void)
  :	DataVector<MooiPatTrack>   ()
{}

inline
MooRoadContainer::~MooRoadContainer (void)
{}

CLASS_DEF(MooRoadContainer, 4048, 1)

#endif // MOOEVENT_MOOROADCONTAINER_H
