#include "MooEvent/GeantinoMap.h"
#include "MooEvent/GeantinoMapMaterial.h"
#include "PathResolver/PathResolver.h"
#include <cmath>

GeantinoMap::GeantinoMap( std::string geantfilename )
{
  m_ioFile = 0;
  m_readStatus = false;

  std::cout << "MooEvent/GeantinoMap::GeantinoMap: Going to open file  " << geantfilename << std::endl;

  std::string geantFileName = PathResolver::find_file (geantfilename, "DATAPATH");
  if ( geantFileName != "") {
    m_readStatus = openFile(geantFileName);
    if ( m_readStatus )  {
      readMap();
      closeFile();
    } else  {
      std::cout << "MooEvent/GeantinoMap::GeantinoMap: Impossible to read from file  " << geantFileName << std::endl;
    }
  } else {
    std::cout << "MooEvent/GeantinoMap::GeantinoMap: PathResolver can't locate " << geantfilename << std::endl;
  }
}

GeantinoMap::~GeantinoMap()
{
}

bool GeantinoMap::isOpen()
{
  return m_readStatus;
}

void GeantinoMap::printMap( int nLines ) 
{
  int lineCount = 0;
  
  std::cout << "MooEvent/GeantinoMap::printMap: Printout of " << nLines << " lines of the geantino step file..." << std::endl;
  std::cout << "   phiBin   thetaBin   nSteps     -->>-->>-- geantino steps -->>-->>" << std::endl;
  
  for ( gMapIter mit = m_geantMap.begin(); mit != m_geantMap.end(); mit++ )
  {
     unsigned key = mit->first;
     std::vector<GeantinoStep> gStepVector = mit->second;
     
     unsigned phiBin   = getPhiBin(key);
     unsigned thetaBin = getThetaBin(key);
     int nSteps = gStepVector.size();
      
     printf("  %i  %i  %i  ",phiBin,thetaBin,nSteps);
     for ( int i = 0; i < nSteps;  i++ )
     { 
       printf("%f %f %f %f\n",gStepVector[i].r,gStepVector[i].X0Sum,gStepVector[i].aSum,gStepVector[i].bSum);
     }  
     lineCount++;
     if ( lineCount >= nLines )  break;
  }        
  std::cout << "MooEvent/GeantinoMap::printMap: End printout of geantino step file." << std::endl;
}

void GeantinoMap::totalRadLengthAndEnergyLoss( double& radLenTot, double& eLossTot, 
                                               double phi, double theta, double rMin, double rMax, double p ) {

  radLenTot = 0.;
  eLossTot = 0.;

  if (!m_readStatus) {
    std::cout << "GeantinoMap::totalRadLengthAndEnergyLoss: WARNING- The map file has not been correctly opened!" << std::endl;
    return;
  }

  if (!containsPhi(phi) || !containsTheta(theta)) {
    std::cout << "GeantinoMap::totalRadLengthAndEnergyLoss: WARNING- The map doesn't cover this theta/phi direction!" << std::endl;
    return;
  }

  double X0Min(0.);
  double ELossMin(0.);
  radLengthAndEnergyLoss( X0Min, ELossMin, phi, theta, rMin, p );

  double X0Max(0.);
  double ELossMax(0.);
  radLengthAndEnergyLoss( X0Max, ELossMax, phi, theta, rMax, p );

  //printf("GeantinoMap X0Max = %f, X0Min = %f --> %f\n",X0Max,X0Min,X0Max-X0Min);

  radLenTot = (X0Max-X0Min);
  eLossTot = (ELossMax-ELossMin);

}

void GeantinoMap::radLengthAndEnergyLoss( double& radLen, double& eLoss, 
                                            double phi, double theta, double radius, double p ) {

  radLen = 0.;
  eLoss = 0.;

  if (!containsPhi(phi) || !containsTheta(theta)) {
    std::cout << "GeantinoMap::totalRadLengthAndEnergyLoss: WARNING- The map doesn't cover this theta/phi direction!" << std::endl;
    return;
  }

  //Return the total integrated rad length and energy loss at r,theta,phi from the map
  unsigned key = getKey( phi, theta );

  // return if the key doesn't exist
  gMapIter mit = m_geantMap.find(key);
  if ( mit == m_geantMap.end() )  {
    std::cout << "GeantinoMap can't find key for theta = " << theta << " and phi = " << phi << std::endl;
    return;
  }

  std::vector<GeantinoStep> stepVector = m_geantMap[key];
  int nSteps = stepVector.size(); 
  
  // return if there is no material in this direction (nSteps = 0)
  if ( !nSteps )  return;
  
  if ( radius > stepVector[nSteps-1].r )  { //ensure that eventually rMap > radius
    radius = stepVector[nSteps-1].r - 0.01;
  }

  // Find the closest entries in the map to radius and interpolate

  float rMapLast(0.); 
  for ( int i = 0; i < nSteps; i++ ) { 
      
     float rMap = stepVector[i].r;

     if ( rMap > radius ) { //calculate X0Initial and ELossInitial

       double X0_1 = 0.;
       double a_1 = 0.;
       double b_1 = 0.;
       if ( i>0 ) {
         X0_1 = stepVector[i-1].X0Sum;
         a_1 = stepVector[i-1].aSum;
         b_1 = stepVector[i-1].bSum;
       }
       double X0_2 = stepVector[i].X0Sum;
       double a_2 = stepVector[i].aSum;
       double b_2 = stepVector[i].bSum;

       double a_av = a_1 + (a_2-a_1)*(radius-rMapLast)/(rMap-rMapLast);
       double b_av = b_1 + (b_2-b_1)*(radius-rMapLast)/(rMap-rMapLast);
       radLen = X0_1 + (X0_2-X0_1)*(radius-rMapLast)/(rMap-rMapLast);
       eLoss = a_av*p + b_av; 

       break;
     } 
     rMapLast = rMap;
  }
}

bool GeantinoMap::openFile( std::string fileName ) 
{
  if ( m_ioFile==NULL ) {
    std::cout << "MooEvent/GeantinoMap::openFile: Open the geantino step file  " << fileName << "  for reading... " << std::endl;
    m_ioFile = new std::fstream( fileName.c_str(), std::ios::in );  // open file to read the geantino step list
    if (m_ioFile!=NULL) return true;
  }
  return false;
}



bool GeantinoMap::closeFile() 
{
  if (m_ioFile) {
    m_ioFile->close();  // close file containing geantino step list
    m_ioFile = 0;
    return true;
  }
  else
  {
    std::cout << "MooEvent/GeantinoMap::closeFile: Trying to close a file never opened!" << std::endl;
    return false;
  } 
}


void GeantinoMap::readMap() 
{
  std::string s;
  int nEntries = 0; //count lines
  unsigned phiBin, thetaBin, nSteps;
  
  while (getline(*m_ioFile, s)) {

    my_isstream istrvar(s.c_str());

    if ( nEntries == 0) {

      istrvar >> m_phiStart >> m_dPhi >> m_thetaStart >> m_dTheta;

    } else {

      std::vector<GeantinoStep> gStepVector;

      istrvar >> phiBin >> thetaBin >> nSteps;

      while ( nSteps ) {
        GeantinoStep gStep;
        istrvar >> gStep.r >> gStep.X0Sum >> gStep.aSum >> gStep.bSum;
 
	gStepVector.push_back(gStep);
	nSteps--;
      }
      insertGeantinoSteps( phiBin, thetaBin, &gStepVector );
    }
    nEntries++;
  }
  m_phiFinish = m_phiStart + phiBin*m_dPhi; 
  m_thetaFinish = m_thetaStart + thetaBin*m_dTheta;

  printf("MooEvent/GeantinoMap::readMap: %i entries read from geantino step file\n",nEntries);
  printf("phiStart = %f --> %f deg, phiFinish = %f --> %f deg, dPhi = %f --> %f deg\n",m_phiStart,m_phiStart*180/M_PI,
	 m_phiFinish,m_phiFinish*180/M_PI,m_dPhi,m_dPhi*180/M_PI);
  printf("thetaStart = %f --> %f deg, thetaFinish = %f --> %f deg, dTheta = %f --> %f deg\n",m_thetaStart,m_thetaStart*180/M_PI,
	 m_thetaFinish,m_thetaFinish*180/M_PI,m_dTheta,m_dTheta*180/M_PI);

  m_phiBinWidth = fabs(m_dPhi);
  m_thetaBinWidth = fabs(m_dTheta);

  m_phiMin = m_phiFinish > m_phiStart ? m_phiStart:m_phiFinish;
  m_thetaMin = m_thetaFinish > m_thetaStart ? m_thetaStart:m_thetaFinish;

  m_phiMax = m_phiFinish > m_phiStart ? m_phiFinish:m_phiStart;
  m_thetaMax = m_thetaFinish > m_thetaStart ? m_thetaFinish:m_thetaStart;

}



bool GeantinoMap::insertGeantinoSteps( unsigned phiBin, 
                                       unsigned thetaBin, 
                                       std::vector<GeantinoStep>* pStepVector )
{
  unsigned key = getKey( phiBin, thetaBin );
  gMapIter mit = m_geantMap.find(key);
  if ( mit == m_geantMap.end() )    // no entry yet
  {
    m_geantMap[key] = *pStepVector;
    return true;
  }
  else
  {
    std::cout << "MooEvent/GeantinoMap::insertGeantinoSteps: DOUBLE key detected!" << std::endl;
    printf("phi = %f\n",(m_phiStart+phiBin*m_dPhi)*180/M_PI);
    printf("theta = %f\n",(m_thetaStart+thetaBin*m_dTheta)*180/M_PI);
    return false;    
  }
}



unsigned GeantinoMap::getPhiBin( double phi ) const {

  phi -= m_phiMin; //translate relative to phiMin = 0;
  while ( phi < 0.) phi += 2*M_PI;
  while ( phi > 2*M_PI ) phi -= 2*M_PI;  

  return (int)(phi/m_phiBinWidth+0.5);

}

unsigned GeantinoMap::getPhiBin( unsigned key ) const
{
  return  key/1000;
}

unsigned GeantinoMap::getThetaBin( double theta ) const
{  
  
  theta -= m_thetaStart;
  unsigned thetaBin = (int)(theta/m_dTheta+0.5);

  return thetaBin;
}



unsigned GeantinoMap::getThetaBin( unsigned key ) const
{
  return  key%1000;
}



unsigned GeantinoMap::getKey( double phi, double theta ) const
{
  unsigned phiBin   = getPhiBin(phi);
  unsigned thetaBin = getThetaBin(theta);
  
  return  phiBin*1000 + thetaBin;
}



unsigned GeantinoMap::getKey( unsigned phiBin, unsigned thetaBin ) const
{
  return  phiBin*1000 + thetaBin;
}


bool GeantinoMap::containsPhi(double phi ) { //phi in radians

  phi -= m_phiMin; //translate relative to phiMin = 0;

  while ( phi < 0.) phi += 2*M_PI;
  while ( phi > 2*M_PI ) phi -= 2*M_PI;  

  if ( phi < (m_phiMax-m_phiMin)) return true;
  return false;
}

bool GeantinoMap::containsTheta(double theta ) {

  if ( theta > m_thetaMin && theta < m_thetaMax ) return true;
  return false;

}


