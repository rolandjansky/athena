#include "MooEvent/MooMdtHit.h"

MooMdtHit::~MooMdtHit (void)
{}

MooMdtHit::MooMdtHit	(const MdtDigit* digit,
			 const HepPoint3D& position,
			 const MuonGM::MdtReadoutElement* chamber,
			 double error_tube)
  :     MooMuonHit     	       ( MooMuonHit(position, chamber->globalPosition()) ),
	m_digit		       ( digit ),
	m_signed_drift	       ( 0. ),
	m_error_drift	       ( 0. ),
	m_error_tube	       ( error_tube ),
	m_residual             ( 0. ),
	m_drift_time_corrected ( 0. ),
	m_second_coordinate    ( 0. ),
	m_descriptor           ( chamber )
{
  if (m_descriptor->getStationS() != 0.) {
    m_T = sqrt(m_T*m_T-m_descriptor->getStationS()*m_descriptor->getStationS());
  } 
}

MooMdtHit::MooMdtHit	(const MooMdtHit& hit)
  :	MooMuonHit	( MooMuonHit(hit) ),
	m_digit		( hit.digit() ),
	m_signed_drift	( hit.SignedDrift() ),
	m_error_drift	( hit.Error() ),
	m_error_tube	( hit.ErrorTube() ),
	m_residual      ( hit.residual() ),
	m_drift_time_corrected ( hit.DriftTimeCorrected() ),
	m_second_coordinate ( hit.SecondCoordinate() ),
	m_descriptor	( hit.detector_descriptor() )
{}

void MooMdtHit::copyDigit ()
{ m_digit = new MdtDigit(*digit()); }
