#ifndef MOOEVENT_MOOMUONHIT_H
# define MOOEVENT_MOOMUONHIT_H

#include "CLHEP/Geometry/Point3D.h"

class Identifier;

class MooMuonHit
{
public:

  MooMuonHit (const HepPoint3D& position, const HepPoint3D& det_position);
  MooMuonHit (const MooMuonHit& hit);
  virtual ~MooMuonHit(void);
    
  const HepPoint3D&        position		(void)	const;
  double     		   phi2pi		(void)	const;
  double     	       	   theta0pi            	(void)	const;
  double                   Tpos                 (void)  const;

  const HepPoint3D&        detector_position	(void)	const;

  virtual Identifier	   HitId       		(void)	const;

protected:

  HepPoint3D   m_position;
  double       m_phi;
  double       m_theta;
  double       m_T;
  HepPoint3D   m_detector_position;
};

inline const HepPoint3D&
MooMuonHit::position	(void)	const
{ return m_position; }

inline double
MooMuonHit::phi2pi     	(void)	const
{ return m_phi; }

inline double
MooMuonHit::theta0pi   	(void)	const
{ return m_theta; }

inline double
MooMuonHit::Tpos   	(void)	const
{ return m_T; }

inline const HepPoint3D&
MooMuonHit::detector_position  	(void)	const
{ return m_detector_position; }

#endif // MOOEVENT_MOOMUONHIT_H
