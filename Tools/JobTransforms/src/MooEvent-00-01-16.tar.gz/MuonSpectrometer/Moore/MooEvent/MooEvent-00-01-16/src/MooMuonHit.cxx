#include "Identifier/Identifier.h"
#include "MooEvent/MooMuonHit.h"

MooMuonHit::~MooMuonHit (void)
{}

MooMuonHit::MooMuonHit	(const HepPoint3D& position, const HepPoint3D& det_position)
  :	m_position		( position ),
	m_T                     ( position.perp() ),
	m_detector_position	( det_position )
  
{
  m_phi 	=	position.phi();
  if (m_phi < 0.) m_phi += 2.*M_PI;
  m_theta 	= 	position.theta();
  if (m_theta < 0.) m_theta += M_PI;
}

MooMuonHit::MooMuonHit	(const MooMuonHit& hit)
  :	m_position		( hit.position() ),
	m_phi			( hit.phi2pi() ),
	m_theta			( hit.theta0pi() ),
	m_T                     ( hit.Tpos() ),
	m_detector_position	( hit.detector_position() )
{}

Identifier
MooMuonHit::HitId      	(void)	const
{ return Identifier(); }
