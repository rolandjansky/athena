#include "MooEvent/MaterialMap.h"
#include "MooEvent/MaterialParameters.h"
#include "PathResolver/PathResolver.h"
#include <cmath>
#include <cassert>
//
bool MaterialMap::status_read=true;
MaterialMap * MaterialMap::myself=0;
MaterialMap::MaterialMap(std::string filename, IOMaterialMap io)
{
  ioFile = 0;
  if (io==READ) {

    std::cout<<" MaterialMap constructor"<<std::endl;
    std::string fileName = PathResolver::find_file (filename, "DATAPATH");
    std::cout << "going to open file " << fileName << std::endl;

    MaterialMap::status_read = false;
    openFileRead(fileName);
    if(MaterialMap::status_read) readMap();
    else {
      std::cout<<"Impossible to read from file "<<fileName<<std::endl;
      closeFile();
      MaterialMap::myself=0;
    }
  }
  else openFileWrite(filename);
}

MaterialMap::~MaterialMap(){
  closeFile();
}

MaterialMap * MaterialMap::getMaterialMap(std::string fileName, IOMaterialMap io) {
  
  if (myself==0) {
      std::cout<<" Create the first/only instance of MaterialMap"<<std::endl;
      myself = new MaterialMap(fileName,io);
  }
  if (status_read==false) MaterialMap::myself=0;
  return myself;
}

bool MaterialMap::openFileRead(std::string fileName) {
    std::cout<<" Open the Map file to read ";
    std::cout<<ioFile<<std::endl;
   
    if (ioFile==0) {
        std::cout<<" ioFile ==0, Open the Map file to read "<<std::endl;
        ioFile = new std::fstream(fileName.c_str(),std::ios::in) ; // Open file for reading the material list.
        if (ioFile->is_open()) status_read=true;
        else {
            MaterialMap::status_read=false;
            std::cout<<fileName<< " does not exist " << std::endl;
        }
    }
    return MaterialMap::status_read;
    //
}

bool MaterialMap::openFileWrite(std::string fileName) {
  fileToWrite=fileName;
  status_read=false;
  return true;
  //
}

bool MaterialMap::closeFile() {
  if (ioFile!=0) {
    ioFile->close(); // Close file for the material list.
    ioFile=0;
  }else{
    std::cout << "trying to close a MateMap.out file never opened!!!"<< std::endl;
  } 
  bool eof=true;
  //
  return eof;
}

bool MaterialMap::insertElement(int eta, int phi, int rad, MaterialParameters mateValue){
  bool status=true;
    int key = getKey(eta,phi,rad);
    itermap iter=mate_map.find(key);
    if(iter==mate_map.end()){
      mate_map[key]=mateValue;
    }else{
      status=false;
      std::cout <<" DOUBLE key detected!!!!!!"<<std::endl;
    }
    return status;
}

int MaterialMap::getEta(int key) {
  int rad=getRadius(key);
  int phi=getPhi(key);
  int eta=std::abs(key)-rad*10000-phi*100;
  if (key<0)eta=-eta;
  return eta;
}

int MaterialMap::getPhi(int key) {
  int keytmp=std::abs(key);
  int rad=getRadius(key);  
  int phi=(keytmp-rad*10000)/100;
  return phi;
}

int MaterialMap::getRadius(int key) {
  int keytmp=std::abs(key);
  int radius=keytmp/10000;
  return radius;
}

bool MaterialMap::writeMap() {
   if (ioFile==0) {
     ioFile = new std::fstream(fileToWrite.c_str(),std::ios::out) ; // Open file for the material list.
   }
   std::string s;
   for (itermap i=mate_map.begin();i!=mate_map.end();i++){
     int key=i->first;
     (*ioFile)<<" "<<getEta(key)<<" "<<getPhi(key)<<" "<<getRadius(key)<<" "<< (mate_map[key]) << std::endl;
   }  
    closeFile();
    return true;
}

bool MaterialMap::readMap() {
  std::string s;
  int entries=0;
  while(getline(*ioFile, s)){
    int eta, phi, rad;
    MaterialParameters mateValue;
    if (entries <  12) std::cout << s << std::endl; // Discards newline char
    if (entries == 12) std::cout << " ... stop here the printout from the Dead Material Map file "<<std::endl;

    //    std::istrstream istrvar(s.c_str());
    my_isstream istrvar(s.c_str());

    istrvar>>eta>>phi>>rad>>mateValue;

    // constant terms in Eloss are in GeV in the Map (DeadMaterialMap_v01.data);
    // convert to MeV
    mateValue.eloss0(mateValue.eloss0()*1000.);
    mateValue.sigmaEloss0(mateValue.sigmaEloss0()*1000.);
    
    insertElement(eta, phi, rad, mateValue);
    entries++;
  }
  std::cout<<" "<<entries<<" Entries have been read from the Dead Material Map file"<<std::endl;
  return true;
}

void MaterialMap::printMap() {
  std::cout<<"Eta "<<"Phi " <<"Radius "<<"NEvents "<<"Thk "<< "DeltaThk "<< "El0 "<<"DeltaEl0 "<< "El1 "<<"DeltaEl1 "<< std::endl;
   for (itermap i=mate_map.begin();i!=mate_map.end();i++){
     int key=i->first;
     std::cout<<" "<<getEta(key)<<" "<<getPhi(key)<<" "<<getRadius(key)<<" "<< (mate_map[key]) << std::endl;
   }  
}

int MaterialMap::getKey(int eta, int phi, int rad){
  int key = std::abs(eta)+100*phi+10000*rad;
  if(eta<0)key= - key;
  return key;
}

int MaterialMap::NbEvents(int eta, int phi, int rad){
  int key=getKey(eta, phi, rad);
  int nev = (mate_map[key]).nEvents();
  return nev;
}

double MaterialMap::Thickness(int eta, int phi, int rad){
  int key=getKey(eta, phi, rad);
  double thick= (mate_map[key]).thickness();
  return thick;
}

double MaterialMap::EnergyLoss0(int eta, int phi, int rad){
  int key=getKey(eta, phi, rad);
  double ener= (mate_map[key]).eloss0();
  return ener;
}

double MaterialMap::EnergyLoss1(int eta, int phi, int rad){
  int key=getKey(eta, phi, rad);
  double ener= (mate_map[key]).eloss1();
  return ener;
}

double MaterialMap::SigmaELoss0(int eta, int phi, int rad){
  int key=getKey(eta, phi, rad);
  double eener= (mate_map[key]).sigmaEloss0();
  return eener;
}

double MaterialMap::SigmaELoss1(int eta, int phi, int rad){
  int key=getKey(eta, phi, rad);
  double eener= (mate_map[key]).sigmaEloss1();
  return eener;
}

double MaterialMap::SigmaThickness(int eta, int phi, int rad){
  int key=getKey(eta, phi, rad);
  double ethick= (mate_map[key]).sigmaThickness();
  return ethick;
}

int MaterialMap::get_map_bins(double phi, double ctheta, int& iphi, int& jphi, int& icth) const
{
    jphi = -1;
    icth = 0;
    iphi = get_phi_bin(phi, jphi);
    if (jphi<0) assert(0);
    icth = get_cotth_bin(ctheta, jphi);
    if (iphi < 1                       ||
        iphi >32                       ||
        icth == 0) 
    {
        std::cout<<"Map bins out of range !!!! iphi, icth "
                 <<iphi<<" "<<icth<<" no DEAD material in this track fit"
                 <<std::endl;
        return 1;
    }
    if (jphi == 1 && abs(icth)>12) {
        std::cout<<"Map bins out of range !!!! iphi, icth "
                 <<iphi<<" "<<icth;
        if (icth > 0) icth = 12;
        else icth = -12;
        std::cout<<" coerce icth to the closest value "<<icth<<std::endl;
    }
    if (jphi != 1 && abs(icth)>11) {
        std::cout<<"Map bins out of range !!!! iphi, icth "
                 <<iphi<<" "<<icth;
        if (icth > 0) icth = 11;
        else icth = -11;
        std::cout<<" coerce icth to the closest value "<<icth<<std::endl;
    }
    return 0;
}

int MaterialMap::get_map_bins(double phi, double ctheta, int& iphi, int& icth) const
{
      // got rid of &:
  int jphi=-1;   //  shank@bu.edu shank Tue Jun  3 15:14:36 2003
  return get_map_bins(phi, ctheta, iphi, jphi, icth);
}

int MaterialMap::get_cotth_bin(double ctheta, int jphi) const
{
    //debug//std::cout<<" %%% Problems? ctheta, jphi = "<<ctheta<<" "<<jphi<<std::endl;
    int icth = 0;
    double barrel_ec_edge=0;
    if (jphi == 1) // large standard sectors // regions A 
    {
	barrel_ec_edge = BarrelL_cth_edge;
    }
    else // regions B,C  
    {	
	barrel_ec_edge = BarrelS_cth_edge;
    }

    //debug//std::cout<<" barrel_ec_edge "<<barrel_ec_edge <<std::endl;
    
    double actheta = fabs(ctheta);
    //debug//std::cout<<" actheta "<<actheta<<std::endl;
    if ( actheta < barrel_ec_edge ) 
    {
	// we are in the barrel 
	double cth = ctheta/Bdcth;
	icth = 0;
	if ( cth > 0. ) icth = (int)cth+1;
	else            icth = (int)cth-1;
        if ( icth > Bnbins_cth ) icth = Bnbins_cth;
        if ( icth <-Bnbins_cth ) icth =-Bnbins_cth;
    }
    else 
    {
	int jcth = -1;
        //debug//std::cout<<" EC region !!! jcth = "<<jcth<<std::endl;
        // we are in the EndCaps
	if (jphi == 1) // Large
	{
	    for (int j=1; j <= NsliceECL_cth && jcth == -1; j++)
	    {
                //debug//std::cout<<" Large Sector:: j, NsliceECL_cth, jcth, ECL_cth_edge[j-1] "
                //debug//         <<j<<" "<<NsliceECL_cth<<" "<<jcth<<" "<<ECL_cth_edge[j-1]
                //debug//         <<std::endl;
		if (actheta < ECL_cth_edge[j-1]) jcth = j;
                //debug//std::cout<<" ---- jcth = "<<jcth<<std::endl;
            }
	}
	else // small 
	{
	    for (int j=1; j <= NsliceECS_cth && jcth == -1; j++)
	    {
                //debug//std::cout<<" Small Sector:: j, NsliceECS_cth, jcth, ECS_cth_edge[j-1] "
                //debug//         <<j<<" "<<NsliceECS_cth<<" "<<jcth<<" "<<ECS_cth_edge[j-1]
                //debug//         <<std::endl;
		if (actheta < ECS_cth_edge[j-1]) jcth = j;
                //debug//std::cout<<" ---- jcth = "<<jcth<<std::endl;
            }	    
	}
	if (jcth > 0) 
	{
	    // skip the barrel bins 
	    icth = Bnbins_cth + jcth;
	    if (ctheta<0) icth = -icth;
            //debug//std::cout<<" ---- icth = "<<icth<<std::endl;
	}
        else 
        { // ctheta is outside the endcap region,close to the beam 
            if (jphi == 1) icth = Bnbins_cth + NsliceECL_cth + 1;
            else icth = Bnbins_cth + NsliceECS_cth+1;
            if (ctheta<0) icth = -icth;
            std::cout<<"MaterialMap::get_cotth_bin %%%%% Error: icth too large for ctheta, jphi = "
                 <<ctheta<<" "<<jphi
                 <<std::endl;
        }
    }
    if (icth == 0) 
    {
        std::cout<<"MaterialMap::get_cotth_bin %%%%% Error: icth=0 (out of range) forctheta, jphi = "
                 <<ctheta<<" "<<jphi
                 <<std::endl;
    }
    //assert(icth);
    return icth;
}

int MaterialMap::get_phi_bin(double phi) const
{
    int jphi=-1;
    return get_phi_bin(phi, jphi);
}

int MaterialMap::get_phi_bin(double phi, int& jphi) const
{
    if (phi <0.)      phi = phi+2.*M_PI;    
    double phip = phi+BdphiLSect/2.;
    if (phip>2.*M_PI) phip= phip-2.*M_PI;
    int ind  = (int)(phip/Bphi4)+1;
    double phipp = double(ind-1)*Bphi4;
    double dphi  = phip-phipp;    
    jphi = 0;
    int iphi = 0;
    if      (dphi<Bphi1)  
	jphi = 1;
    else if (dphi<Bphi2) 
	jphi = 2;	
    else if (dphi<Bphi3)  
	jphi = 3;	
    else if (dphi<Bphi4)
	jphi = 4;

    
    iphi =  (ind-1)*4+jphi;
    return iphi;    
}

const int   MaterialMap::Bnbins_phi = 32;
const int   MaterialMap::Bnbins_cth =  6;
const int   MaterialMap::Bnbins_r   =  3;
const double MaterialMap::BdphiLSect       = 0.4939;
const double MaterialMap::BdphiSSectClear  = 0.07075;
const double MaterialMap::BdphiSSectCoils  = 0.15;
const double MaterialMap::Bphi0 = 0.;
const double MaterialMap::Bphi1 = BdphiLSect;  
const double MaterialMap::Bphi2 = Bphi1 + BdphiSSectClear;  
const double MaterialMap::Bphi3 = Bphi2 + BdphiSSectCoils;
const double MaterialMap::Bphi4 = Bphi3 + BdphiSSectClear;
const double MaterialMap::Bdcth      = 0.2;
const double MaterialMap::Br0SSect   = 466.7;
const double MaterialMap::Br1SSect   = 838.2;
const double MaterialMap::Br2SSect   =1078.6;
const double MaterialMap::Br0LSect   = 513.4;
const double MaterialMap::Br1LSect   = 750.3;
const double MaterialMap::Br2LSect   = 986.4;
const double MaterialMap::BarrelL_cth_edge   = 1.23700;
const double MaterialMap::BarrelS_cth_edge   = 1.17655;
const int MaterialMap::NsliceECL_cth = 6;
const double MaterialMap::ECL_cth_edge[6]={
    1.31993,
    1.81311,
    3.13499,
    3.62608,
    5.46627,
    7.40576
};
const int MaterialMap::NsliceECS_cth = 5;
const double MaterialMap::ECS_cth_edge[5]={
    1.77532,
    3.11333,
    3.60789,
    5.40687,
    7.78150
};
