#include <iostream>
#include "MooEvent/MaterialParameters.h"
MaterialParameters::MaterialParameters(){
  _nevents=0;
  _thickness=0;
  _sigmaThickness=0;
  _eloss0=0;
  _eloss1=0;
  _sigmaEloss0=0;
  _sigmaEloss1=0;
}
MaterialParameters::MaterialParameters(int nEv, double Thk, double sThk, double El0, double sEl0, double El1, double sEl1){
  _nevents=nEv;
  _thickness=Thk;
  _sigmaThickness=sThk;
  _eloss0=El0;
  _eloss1=El1;
  _sigmaEloss0=sEl0;
  _sigmaEloss1=sEl1;
}
int MaterialParameters::nEvents() const { return _nevents;}
double MaterialParameters::thickness() const { return _thickness;}
double MaterialParameters::sigmaThickness() const { return _sigmaThickness;}
double MaterialParameters::eloss0() const { return _eloss0;}
double MaterialParameters::sigmaEloss0() const { return _sigmaEloss0;}
double MaterialParameters::eloss1() const { return _eloss1;}
double MaterialParameters::sigmaEloss1() const { return _sigmaEloss1;}
//
void MaterialParameters::nEvents(int x)  { _nevents=x;}
void MaterialParameters::thickness(double x)  { _thickness=x;}
void MaterialParameters::sigmaThickness(double dx)  {_sigmaThickness= dx;}
void MaterialParameters::eloss0(double x)  { _eloss0=x;}
void MaterialParameters::sigmaEloss0(double dx)  { _sigmaEloss0=dx;}
void MaterialParameters::eloss1(double x)  { _eloss1=x;}
void MaterialParameters::sigmaEloss1(double dx) { _sigmaEloss1=dx;}
// output to stdout operator
std::ostream & operator<<(std::ostream & os, const MaterialParameters & MP) {
  os<< MP._nevents         << " " 
    << MP._thickness       << " " 
    << MP._sigmaThickness  << " "
    << MP._eloss0          << " "
    << MP._sigmaEloss0     << " "
    << MP._eloss1          << " "
    << MP._sigmaEloss1;
   return os;
}
// input from stdin operator
std::istream & operator>>(std::istream & is, MaterialParameters & MP) {
   is>>MP._nevents>>MP._thickness>>
     MP._sigmaThickness>>MP._eloss0>>
     MP._sigmaEloss0>>MP._eloss1>>MP._sigmaEloss1;
   return is;
}
