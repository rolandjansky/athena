if test "${CMTROOT}" = ""; then
  CMTROOT=/storage/scratch/atlas/releases-latest/CMT/v1r16p20040901; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=MooEvent -version=MooEvent-00-01-16 -path=/storage/data5/atlas/validation/Production/Tools/JobTransforms/JobTransforms-00-03-01/src/MuonSpectrometer/Moore $* >${tempfile}; . ${tempfile}
/bin/rm -f ${tempfile}

