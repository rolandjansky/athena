#include "MooEvent/MooRpcHit.h"

MooRpcHit::~MooRpcHit (void)
{}

MooRpcHit::MooRpcHit	(std::vector<const RpcDigit*>& digits,
			 const HepPoint3D& position,
			 const MuonGM::RpcReadoutElement* chamber,
			 double error)
  :	MooMuonHit	( MooMuonHit(position, chamber->globalPosition()) ),
	m_digits	( digits ),
	m_id            ( (*(m_digits.begin()))->identify() ),
	m_descriptor	( chamber ),
	m_error         ( error )
{
  if (m_descriptor->getStationS() != 0.) {
    m_T = sqrt(m_T*m_T-m_descriptor->getStationS()*m_descriptor->getStationS());
  } 
}

MooRpcHit::MooRpcHit	(const MooRpcHit& hit)
  :	MooMuonHit	( MooMuonHit(hit) ),
	m_id		( hit.HitId() ),
	m_descriptor	( hit.detector_descriptor() ),
	m_error         ( hit.Error() )
{ std::copy(hit.digits_begin(), hit.digits_end(), back_inserter(m_digits)); }


