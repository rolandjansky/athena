#include <iomanip>
#include <iostream>
//
#include "MuonIdHelpers/MuonIdHelper.h"
#include "MooEvent/MooiPatTrack.h"

MooiPatTrack::MooiPatTrack (void)
{}

MooiPatTrack::MooiPatTrack (const MooiPatTrack& track)
  : Track	       	(track),
    m_muon_status      	(track.muon_status()),
    m_mdt_hits_count    (track.mdt_hits_count()),
    m_csc_hits_count    (track.csc_hits_count()),
    m_rpc_hits_count    (track.rpc_hits_count()),
    m_tgc_hits_count    (track.tgc_hits_count()),
    m_phi_hits_count    (track.phi_hits_count())
{
  m_status		=	muon;
  // Copy the station_layers set
  m_station_layers.insert ( track.station_layers_begin(), track.station_layers_end() );
  // Copy the phi_layers set
  m_phi_layers.insert ( track.phi_layers_begin(),  track.phi_layers_end() );
}

MooiPatTrack::MooiPatTrack( std::string muon_status,
			    std::list<HitOnTrack*>&  hits,
			    std::set<unsigned>&      station_layers,
			    std::set<unsigned>&	     phi_layers,
			    int&                     mdt_hits,
			    int&                     csc_hits,
			    int&                     rpc_hits,
			    int&                     tgc_hits,
			    int&                     phi_hits,
			    PerigeeParameters*       perigee,
			    FitQuality*              fit_quality,
			    HitQuality*              hit_quality)
  : Track  ()
{
  m_muon_status     =  muon_status;
  m_status	    =  muon;

  m_mdt_hits_count  =  mdt_hits;
  m_csc_hits_count  =  csc_hits;
  m_rpc_hits_count  =  rpc_hits;
  m_tgc_hits_count  =  tgc_hits;
  m_phi_hits_count  =  phi_hits;
  
  // Copy the station_layers set
  m_station_layers.insert ( station_layers.begin(), station_layers.end() );
  // Copy the phi_layers set
  m_phi_layers.insert ( phi_layers.begin(), phi_layers.end() );
  // Copy the hits of the road track
  for (hit_const_iterator h = hits.begin(); h != hits.end(); ++h)
    m_hits.push_back( *h );
  m_perigee_parameters	=	perigee;
  m_fit_quality		=	fit_quality;
  m_hit_quality		=	hit_quality;

}

MooiPatTrack::MooiPatTrack( std::string muon_status,
			    std::list<HitOnTrack*>&  hits,
			    std::set<unsigned>&      station_layers,
			    std::set<unsigned>&	     phi_layers,
			    int&                     mdt_hits,
			    int&                     csc_hits,
			    int&                     rpc_hits,
			    int&                     tgc_hits,
			    int&                     phi_hits,
			    PerigeeParameters*       perigee,
			    FitQuality*              fit_quality,
			    HitQuality*              hit_quality,
			    parameter_vector&         sc_params)
  : Track  ()
{
  m_muon_status     =  muon_status;
  m_status	    =  muon;

  m_mdt_hits_count  =  mdt_hits;
  m_csc_hits_count  =  csc_hits;
  m_rpc_hits_count  =  rpc_hits;
  m_tgc_hits_count  =  tgc_hits;
  m_phi_hits_count  =  phi_hits;
  
  // Copy the station_layers set
  m_station_layers.insert ( station_layers.begin(), station_layers.end() );
  // Copy the phi_layers set
  m_phi_layers.insert ( phi_layers.begin(), phi_layers.end() );
  // Copy the hits of the road track
  for (hit_const_iterator h = hits.begin(); h != hits.end(); ++h)
    m_hits.push_back( *h );
  m_perigee_parameters	=	perigee;
  m_fit_quality		=	fit_quality;
  m_hit_quality		=	hit_quality;
  for (parameter_const_iterator s = sc_params.begin(); s != sc_params.end(); ++s)
    m_parameter_vector.push_back(*s);

}

void
MooiPatTrack::print	(const MuonIdHelper* helper)
{
  print_muon_parameters();
  print_muon_hits_summary();
  print_muon_hits( helper );
}

void
MooiPatTrack::print_muon_hits	(const MuonIdHelper* helper)
{
  std::cout << "      i  Det      Rho      Phi       Z       CotTh    DrD     Sig     Res    Identifier"
	    << std::endl;
  int i = 1;
  for (hit_const_iterator h = hit_list_begin(); h != hit_list_end(); ++h, ++i) {
    if ( (*h)->status() == scatterer ) {
      std::cout << setiosflags(std::ios::fixed);
      std::cout << "    " << std::setw(3) << i << " Scatter"
		<< std::setw(9) << std::setprecision(3) << (*h)->position().perp() << "         "
		<< std::setw(9) << std::setprecision(3) << (*h)->position().z() << " X0 "
		<< std::setw(6) << std::setprecision(3) << (*h)->radiation_thickness();
      std::cout << std::resetiosflags(std::ios::fixed)
		<< std::endl;
    } else if ( (*h)->status() == inert ) {
      std::cout << setiosflags(std::ios::fixed);
      std::cout << "    " << std::setw(3) << i << " Inert "
		<< std::setw(9) << std::setprecision(3) << (*h)->position().perp() << "         "
		<< std::setw(9) << std::setprecision(3) << (*h)->position().z() << " X0 "
		<< std::setw(6) << std::setprecision(3) << (*h)->radiation_thickness();
      std::cout << std::resetiosflags(std::ios::fixed)
		<< std::endl;
    } else {
      std::string		det_type;
      if ( helper->is_rpc((*h)->identifier()) ) {
	det_type  =  " R-Z   ";
	if ( fabs((*h)->sin_stereo()) < 0.5 ) det_type  =  " R-Phi ";
      } else if ( helper->is_tgc((*h)->identifier()) ) {
	det_type  =  " T-R   ";
	if ( fabs((*h)->sin_stereo()) < 0.5 ) det_type  =	" T-Phi ";
      } else if ( helper->is_csc((*h)->identifier()) ) {
	det_type  =  " C-R   ";
	if ( fabs((*h)->sin_stereo()) < 0.5 ) det_type  =	" C-Phi ";
      } else if ( helper->is_mdt((*h)->identifier()) ) {
	det_type  =  " MDT   ";
      }

      double	phi = (*h)->position().phi();
      if (phi < 0.) phi = phi + (2*M_PI);
      if ((*h)->is_drift()) {
	std::cout << setiosflags(std::ios::fixed);
	std::cout << "    " << std::setw(3) << i << det_type
		  << std::setw(9) << std::setprecision(3) << (*h)->position().perp() 	  << " "
		  << std::setw(7) << std::setprecision(3) << phi 	                          << " "
		  << std::setw(9) << std::setprecision(3) << (*h)->position().z() 		  << " "
		  << std::setw(8) << std::setprecision(3) << 1./tan((*h)->position().theta())  << " "
		  << std::setw(7) << std::setprecision(2) << (*h)->signed_drift_distance() 	  << " "
		  << std::setw(7) << std::setprecision(2) << (*h)->sigma() 			  << " "
		  << std::setw(7) << std::setprecision(2) << (*h)->residual()	          << " "
		  << helper->show_to_string((*h)->identifier());
	std::cout << std::resetiosflags(std::ios::fixed)
		  << std::endl;
      } else {
	std::cout << setiosflags(std::ios::fixed);
	std::cout << "    " << std::setw(3) << i << det_type
		  << std::setw(9) << std::setprecision(3) << (*h)->position().perp()	<< " "
		  << std::setw(7) << std::setprecision(3) << phi		        << " "
		  << std::setw(9) << std::setprecision(3) << (*h)->position().z() 	<< " "
		  << std::setw(8) << std::setprecision(3) << (*h)->position().z()/(*h)->position().perp() << "         "
		  << std::setw(7) << std::setprecision(2) << (*h)->sigma() 			  << " "
		  << std::setw(7) << std::setprecision(2) << (*h)->residual()      		  << " "
		  << helper->show_to_string((*h)->identifier());
	std::cout << std::resetiosflags(std::ios::fixed)
		  << std::endl;
      }
    }
  }
}

void
MooiPatTrack::print_muon_parameters	(void)
{
  if ( has_perigee_parameters() ) {
    double	vphi	=	perigee_parameters().position().phi();
    if (vphi < 0.) vphi = vphi + (2*M_PI);
    std::cout << setiosflags(std::ios::fixed);
    std::cout << "Rho, Phi, Z "
	      << std::setw(9) << std::setprecision(3) << perigee_parameters().position().perp() 	<< " "
	      << std::setw(7) << std::setprecision(3) << vphi      	                                << " "
	      << std::setw(9) << std::setprecision(3) << perigee_parameters().position().z()         << "  phi,dzdr "
	      << std::setw(7) << std::setprecision(4) << perigee_parameters().phi()
	      << std::setw(8) << std::setprecision(4) << perigee_parameters().cot_theta()  	<< "  pt"
	      << std::setw(8) << std::setprecision(2) << perigee_parameters().pt()         	<< " Chi2 "
	      << std::setw(5) << std::setprecision(2) << fit_quality().chi_squared();
    std::cout << std::resetiosflags(std::ios::fixed)
	      << std::endl;
  } else {
    std::cout << "!!!! Track has NO perigee parameters !!!!" << std::endl;
  }
}

void
MooiPatTrack::print_muon_hits_summary	(void)
{
  std::cout << setiosflags(std::ios::fixed);
  std::cout << "Station Layers:";
  for (std::set<unsigned>::const_iterator l = m_station_layers.begin(); l != m_station_layers.end(); ++l)
    std::cout << " " << *l;
  std::cout << " TPhi "
	    << std::setw(3) << m_phi_hits_count	       << " MDT "
	    << std::setw(3) << m_mdt_hits_count	       << " CSC "
	    << std::setw(3) << m_csc_hits_count        << " Status "
	    << m_muon_status;
  std::cout << std::resetiosflags(std::ios::fixed)
	    << std::endl;


}

