#include "MooEvent/MooTgcHit.h"

MooTgcHit::~MooTgcHit (void)
{}

MooTgcHit::MooTgcHit	(std::vector<const TgcDigit*>& digits,
			 const HepPoint3D& position,
			 const MuonGM::TgcReadoutElement* chamber,
			 double error)
  :	MooMuonHit	( MooMuonHit(position, chamber->globalPosition()) ),
	m_digits	( digits ),
	m_id            ( (*(m_digits.begin()))->identify() ),
	m_descriptor	( chamber ),
	m_error         ( error )
{
  if (m_descriptor->getStationS() != 0.) {
    m_T = sqrt(m_T*m_T-m_descriptor->getStationS()*m_descriptor->getStationS());
  } 
}

MooTgcHit::MooTgcHit	(const MooTgcHit& hit)
  :	MooMuonHit	( MooMuonHit(hit) ),
	m_id		( hit.HitId() ),
	m_descriptor	( hit.detector_descriptor() ),
	m_error         ( hit.error_at_start() )
{ std::copy(hit.digits_begin(), hit.digits_end(), back_inserter(m_digits)); }

