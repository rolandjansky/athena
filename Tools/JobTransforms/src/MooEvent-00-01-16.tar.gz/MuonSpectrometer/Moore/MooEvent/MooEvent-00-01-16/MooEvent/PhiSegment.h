#ifndef MOOEVENT_PHISEGMENT_H
# define MOOEVENT_PHISEGMENT_H

#include <vector>

class Identifier;
class MuonIdHelper;
class MooMuonHit;

class PhiSegment
{
public:
  PhiSegment (void);
  PhiSegment (std::vector<MooMuonHit*>&	digits,
	      std::vector<Identifier>&	detectors,
	      double&		       	phi);
  ~PhiSegment();

  double     				        phi		(void) const;
   
  std::vector<MooMuonHit*>::const_iterator	hits_begin	(void) const;
  std::vector<MooMuonHit*>::const_iterator	hits_end	(void) const;
  std::vector<Identifier>::const_iterator	detectors_begin	(void) const;
  std::vector<Identifier>::const_iterator	detectors_end	(void) const;

  void	print	(const MuonIdHelper* helper) const ;

private:
  std::vector<MooMuonHit*>  m_hits;
  std::vector<Identifier>   m_detectors;
    
  double                    m_phi;
    
};

inline double
PhiSegment::phi	(void) const
{ return m_phi;}

inline std::vector<MooMuonHit*>::const_iterator
PhiSegment::hits_begin	(void) const
{ return m_hits.begin();}

inline std::vector<MooMuonHit*>::const_iterator
PhiSegment::hits_end	(void) const
{ return m_hits.end();}

inline std::vector<Identifier>::const_iterator
PhiSegment::detectors_begin	(void) const
{ return m_detectors.begin();}

inline std::vector<Identifier>::const_iterator
PhiSegment::detectors_end	(void) const
{ return m_detectors.end();}

#endif // MOOEVENT_PHISEGMENT_H




