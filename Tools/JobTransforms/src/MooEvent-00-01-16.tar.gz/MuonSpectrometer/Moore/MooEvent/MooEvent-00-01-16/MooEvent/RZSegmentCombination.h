#ifndef MOOEVENT_RZSEGMENTCOMBINATION_H
# define MOOEVENT_RZSEGMENTCOMBINATION_H

#include <vector>

class MooRZSegment;

class RZSegmentCombination
{
public:

  RZSegmentCombination	(std::vector<MooRZSegment*>& segs);

  std::vector<MooRZSegment*>::const_iterator segments_begin (void) const;
  std::vector<MooRZSegment*>::const_iterator segments_end   (void) const;

  unsigned segments_count (void) const;
  unsigned hits_count     (void) const;
  double   min_theta      (void) const;
  double   max_theta      (void) const;
  
private:

  std::vector<MooRZSegment*> m_segments;
  unsigned                   m_hits_count;

  double                     m_min_theta;
  double                     m_max_theta;
  
};

inline std::vector<MooRZSegment*>::const_iterator
RZSegmentCombination::segments_begin (void) const
{ return m_segments.begin(); }

inline std::vector<MooRZSegment*>::const_iterator
RZSegmentCombination::segments_end (void) const
{ return m_segments.end(); }

inline unsigned
RZSegmentCombination::segments_count (void) const
{ return m_segments.size(); }

inline unsigned
RZSegmentCombination::hits_count (void) const
{ return m_hits_count; }

inline double
RZSegmentCombination::min_theta   (void) const
{ return m_min_theta; }

inline double
RZSegmentCombination::max_theta   (void) const
{ return m_max_theta; }

#endif // MOOEVENT_RZSEGMENTCOMBINATION_H







