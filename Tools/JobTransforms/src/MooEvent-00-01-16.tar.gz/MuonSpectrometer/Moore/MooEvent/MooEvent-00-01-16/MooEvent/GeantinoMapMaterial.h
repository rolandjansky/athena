/***************************************************************************
 Class to read material and geantino step data from files, fill appropriate 
 map/vector structures, and provide tools to access the data.   
 -------------------------------------------
 Copyright (C) 2003 by ATLAS Collaboration
 ***************************************************************************/

#ifndef MOOEVENT_GEANTINOMAPMATERIAL_H
#define MOOEVENT_GEANTINOMAPMATERIAL_H



//<<<<<< INCLUDES                                                       >>>>>>

#include <vector>
#include <map>
#include <fstream>
#include <iostream>
#include <string>

// stringstreams working with gcc2.95 and gcc3.2 (cf. http://annwm.lbl.gov/~leggett/Atlas/gcc-3.2.html)
#ifdef HAVE_NEW_IOSTREAMS
  #include <sstream>
  typedef std::istringstream my_isstream;
#else
  #include <strstream>
  typedef strstream my_isstream;
#endif


//<<<<<< PUBLIC DEFINES                                                 >>>>>>
//<<<<<< PUBLIC CONSTANTS                                               >>>>>>
//<<<<<< PUBLIC TYPES                                                   >>>>>>


///---------------------------------------------------------------------------------------
/// Material properties needed here are 
///
///  - radiation length
///
///  - energy loss parameters a,b (const) as occurring in the approximate relation
///
///       dE/dx = -( a*E + b )             (1)
///
///    The solution is  
///
///       E(x) = -b/a + ( E0 + b/a ) * exp( -a*x ),  where E0 := E(0).  
///
///    If a*x << 1, this can be approximated by  
///
///       E0 - E(x) = ( E0*a + b ) * x     (2)
///
///    Relation (2) will be used throughout this application. 
///---------------------------------------------------------------------------------------
struct MaterialProperties
{
   double radLength;    // radiation length [mm]
   double aEloss;       // energy loss parameter a (cf. (1); [a] = 1/mm)    
   double bEloss;       // energy loss parameter b (cf. (1); [b] = MeV/mm)
};



//<<<<<< PUBLIC VARIABLES                                               >>>>>>
//<<<<<< PUBLIC FUNCTIONS                                               >>>>>>
//<<<<<< CLASS DECLARATIONS                                             >>>>>>

class GeantinoMapMaterial
{
  public:
  
    static GeantinoMapMaterial* getGeantinoMapMaterial( std::string fileName );
    
    ~GeantinoMapMaterial();
    
    void printMap();

    bool insertMaterial( unsigned matID, MaterialProperties matProp );
  
    // methods to retrieve radiation length, Eloss parameters associated with a given material 
    double getRadLength( unsigned matID );
    double getAEloss   ( unsigned matID );
    double getBEloss   ( unsigned matID );

    // methods to set radiation length, Eloss parameters associated with a given material 
    void setRadLength( unsigned matID, double radLength );
    void setAEloss   ( unsigned matID, double aEloss );
    void setBEloss   ( unsigned matID, double bEloss );
    
  
  private:
  
    //------------------------------------------------------------------------------------
    // private methods
    GeantinoMapMaterial( std::string fileName );
  
    bool openFile( std::string fileName );
    bool closeFile();
  
    void readMap();


    //------------------------------------------------------------------------------------
    // private data members
    static GeantinoMapMaterial* s_myself;
    
    std::map< unsigned, MaterialProperties >  m_matMap;
    typedef std::map< unsigned, MaterialProperties >::const_iterator  matMapIter;

    std::fstream* m_ioFile;

};



//<<<<<< INLINE PUBLIC FUNCTIONS                                        >>>>>>
//<<<<<< INLINE MEMBER FUNCTIONS                                        >>>>>>


#endif // MOOEVENT_GEANTINOMAPMATERIAL_H
