#ifndef MOOEVENT_MOOTGCHIT_H
# define MOOEVENT_MOOTGCHIT_H

#include "MooEvent/MooMuonHit.h"
#include "MuonDigitContainer/TgcDigit.h"
#include "MuonGeoModel/TgcReadoutElement.h"

class MooTgcHit: public MooMuonHit
{
public:

  MooTgcHit (std::vector<const TgcDigit*>& digits,
	     const HepPoint3D& position,
	     const MuonGM::TgcReadoutElement* chamber,
	     double error);
  MooTgcHit (const MooTgcHit& hit);
  ~MooTgcHit (void);

  std::vector<const TgcDigit*>::const_iterator	digits_begin	(void)	const;
  std::vector<const TgcDigit*>::const_iterator	digits_end	(void)	const;
    
  double Error (double& rho_hit) const;

  Identifier	        HitId		(void)	const;
    
  const MuonGM::TgcReadoutElement*	detector_descriptor	(void)	const;

private:
  std::vector<const TgcDigit*>	    m_digits;
  Identifier   			    m_id;
  const MuonGM::TgcReadoutElement*  m_descriptor;
  double                            m_error;

  double error_at_start        (void) const;
};

inline	std::vector<const TgcDigit*>::const_iterator
MooTgcHit::digits_begin	(void)	const
{ return m_digits.begin(); }

inline	std::vector<const TgcDigit*>::const_iterator
MooTgcHit::digits_end	(void)	const
{ return m_digits.end(); }

inline	Identifier
MooTgcHit::HitId	(void)	const
{ return m_id; }

inline	const MuonGM::TgcReadoutElement*
MooTgcHit::detector_descriptor	(void)	const
{ return m_descriptor; }

inline double
MooTgcHit::Error (double& rho_hit) const
{ return m_error * rho_hit; }

inline double
MooTgcHit::error_at_start (void) const
{ return m_error; }

#endif // MOOEVENT_MOOTGCHIT_H
