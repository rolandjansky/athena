#ifndef MOOEVENT_MOOCSCHIT_H
# define MOOEVENT_MOOCSCHIT_H

#include "MooEvent/MooMuonHit.h"
#include "MuonDetCluster/CscCluster.h"
#include "MuonGeoModel/CscReadoutElement.h"

class Identifier;

class MooCscHit: public MooMuonHit
{
public:

  MooCscHit (CscCluster* cluster,
	     const MuonGM::CscReadoutElement* chamber);
  MooCscHit (MooCscHit& hit);
  ~MooCscHit (void);

  CscCluster*	cluster (void)	const;
    
  double Error (double& rho_hit);

  Identifier	        HitId		(void)	const;
    
  const MuonGM::CscReadoutElement*	detector_descriptor	(void)	const;
    
private:
  
  CscCluster*	                    m_cluster;
  Identifier			    m_id;
  const MuonGM::CscReadoutElement*  m_descriptor;

};

inline CscCluster*
MooCscHit::cluster	(void)	const
{ return m_cluster; }

inline	Identifier
MooCscHit::HitId	(void)	const
{ return m_id; }

inline	const MuonGM::CscReadoutElement*
MooCscHit::detector_descriptor	(void)	const
{ return m_descriptor; }

inline double 
MooCscHit::Error (double& rho_hit)
{ return  m_cluster->sigma(); }
// { return  0.1; }

#endif // MOOEVENT_MOOCSCHIT_H
