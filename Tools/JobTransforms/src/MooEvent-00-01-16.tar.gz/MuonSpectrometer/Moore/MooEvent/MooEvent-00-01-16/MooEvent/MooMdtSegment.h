#ifndef MOOEVENT_MOOMDTSEGMENT_H
# define MOOEVENT_MOOMDTSEGMENT_H

#include <vector>
#include <set>

#include "MooEvent/MooRZSegment.h"
#include "MuonGeoModel/MdtReadoutElement.h"
#include "MuonIdHelpers/MdtIdHelper.h"
#include "MooEvent/MooMdtHit.h"

class MooMdtSegment: public MooRZSegment
{
public:
  MooMdtSegment	(std::vector<MooMdtHit*>& hits, const MdtIdHelper* helper);
  MooMdtSegment	(std::vector<MooMdtHit*>& hits,
		 const double& alpha,
		 const double& Dalpha,
		 const double& beta,
		 const double& Dbeta,
		 const double& off_diagonal,
		 const double& Chi2,
		 const int&    nDegF,
		 const MdtIdHelper* helper);
  MooMdtSegment (const MooMdtSegment&); // Copy constructor
  ~MooMdtSegment	(void);
    
  std::vector<MooMdtHit*>::iterator	        hits_begin	(void);
  std::vector<MooMdtHit*>::iterator	        hits_end	(void);
  std::vector<MooMdtHit*>::const_iterator       hits_cbegin	(void) const;
  std::vector<MooMdtHit*>::const_iterator       hits_cend	(void) const;
  std::vector<MooMdtHit*>::reverse_iterator	hits_rbegin	(void);
  std::vector<MooMdtHit*>::reverse_iterator	hits_rend	(void);
  
  unsigned  hits_count	     (void) const;

  std::set<int>::const_iterator  multilayers_begin (void) const;
  std::set<int>::const_iterator  multilayers_end (void) const;
  unsigned                       multilayer_count (void) const;

  const MuonGM::MdtReadoutElement*  detector_descriptor	(void)	const;
  const HepPoint3D&                 detector_position	(void)	const;
    
  void	print_parameters       	(void);
  void	print_hits		(const MdtIdHelper* helper);
  void	print			(const MdtIdHelper* helper);

  // For Rome Calib Algs
  void copyDigit ();

private:
  // Data members
  std::vector<MooMdtHit*>  m_hits;
  std::set<int>		   m_multilayers;
  
  // For Rome Calib Algs
  int m_privateDigit;

  // Private methods
};

inline unsigned
MooMdtSegment::hits_count	(void)	const
{ return m_hits.size(); }

inline std::set<int>::const_iterator
MooMdtSegment::multilayers_begin (void) const
{ return m_multilayers.begin(); }

inline std::set<int>::const_iterator
MooMdtSegment::multilayers_end (void) const
{ return m_multilayers.end(); }

inline unsigned
MooMdtSegment::multilayer_count	(void)	const
{ return m_multilayers.size(); }

inline std::vector<MooMdtHit*>::iterator
MooMdtSegment::hits_begin	(void)
{ return m_hits.begin(); }

inline std::vector<MooMdtHit*>::iterator
MooMdtSegment::hits_end	(void)
{ return m_hits.end(); }

inline std::vector<MooMdtHit*>::const_iterator
MooMdtSegment::hits_cbegin	(void)	const
{ return m_hits.begin(); }

inline std::vector<MooMdtHit*>::const_iterator
MooMdtSegment::hits_cend	(void)	const
{ return m_hits.end(); }

inline std::vector<MooMdtHit*>::reverse_iterator
MooMdtSegment::hits_rbegin	(void)
{ return m_hits.rbegin(); }

inline std::vector<MooMdtHit*>::reverse_iterator
MooMdtSegment::hits_rend	(void)
{ return m_hits.rend(); }

inline  const MuonGM::MdtReadoutElement*
MooMdtSegment::detector_descriptor	(void)	const
{ return m_hits.front()->detector_descriptor(); }
 
inline  const HepPoint3D&
MooMdtSegment::detector_position	(void)	const
{ return m_hits.front()->detector_position(); }

#endif // MOOEVENT_MOOMDTSEGMENT_H
