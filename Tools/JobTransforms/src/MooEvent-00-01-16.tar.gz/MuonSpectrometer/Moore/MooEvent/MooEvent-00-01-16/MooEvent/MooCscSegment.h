#ifndef MOOEVENT_MOOCSCSEGMENT_H
# define MOOEVENT_MOOCSCSEGMENT_H

#include <vector>
#include <set>

#include "MuonGeoModel/MdtReadoutElement.h"
#include "MuonIdHelpers/CscIdHelper.h"
#include "MooEvent/MooRZSegment.h"
#include "MooEvent/MooCscHit.h"

class MooCscSegment: public MooRZSegment
{
public:
  MooCscSegment	(std::vector<MooCscHit*>& hits, const CscIdHelper* helper);
  MooCscSegment	(std::vector<MooCscHit*>& hits,
		 double z,
		 double rho,
		 double theta,
		 double SumOfResiduals,
		 const CscIdHelper* helper);
  MooCscSegment (const MooCscSegment&); // Copy constructor
  ~MooCscSegment	(void);
    
  std::vector<MooCscHit*>::iterator	        hits_begin	(void);
  std::vector<MooCscHit*>::iterator	        hits_end	(void);
  std::vector<MooCscHit*>::const_iterator       hits_cbegin	(void) const;
  std::vector<MooCscHit*>::const_iterator       hits_cend	(void) const;
  std::vector<MooCscHit*>::reverse_iterator	hits_rbegin	(void);
  std::vector<MooCscHit*>::reverse_iterator	hits_rend	(void);
  
  unsigned  hits_count	     (void) const;
    
  const MuonGM::CscReadoutElement*  detector_descriptor	(void)	const;
  const HepPoint3D&                 detector_position	(void)	const;
    
  void	print_parameters       	(void);
  void	print_hits		(const CscIdHelper* helper);
  void	print			(const CscIdHelper* helper);

private:
  // Data memebrs
  std::vector<MooCscHit*>  m_hits;
  
  // Private methods
};

inline unsigned
MooCscSegment::hits_count	(void)	const
{ return m_hits.size(); }

inline std::vector<MooCscHit*>::iterator
MooCscSegment::hits_begin	(void)
{ return m_hits.begin(); }

inline std::vector<MooCscHit*>::iterator
MooCscSegment::hits_end	(void)
{ return m_hits.end(); }

inline std::vector<MooCscHit*>::const_iterator
MooCscSegment::hits_cbegin	(void)	const
{ return m_hits.begin(); }

inline std::vector<MooCscHit*>::const_iterator
MooCscSegment::hits_cend	(void)	const
{ return m_hits.end(); }

inline std::vector<MooCscHit*>::reverse_iterator
MooCscSegment::hits_rbegin	(void)
{ return m_hits.rbegin(); }

inline std::vector<MooCscHit*>::reverse_iterator
MooCscSegment::hits_rend	(void)
{ return m_hits.rend(); }

inline  const MuonGM::CscReadoutElement*
MooCscSegment::detector_descriptor	(void)	const
{ return m_hits.front()->detector_descriptor(); }
 
inline  const HepPoint3D&
MooCscSegment::detector_position	(void)	const
{ return m_hits.front()->detector_position(); }

#endif // MOOEVENT_MOOCSCSEGMENT_H
