#include <iomanip>
#include <iostream>

#include "MooEvent/MooMdtSegment.h"

MooMdtSegment::MooMdtSegment 	(std::vector<MooMdtHit*>& hits, const MdtIdHelper* helper)
  : MooRZSegment ( )
{
  for (std::vector<MooMdtHit*>::const_iterator h = hits.begin(); h != hits.end(); ++h) {
    m_hits.push_back(new MooMdtHit(**h));
    m_multilayers.insert( helper->multilayer((*h)->digit()->identify()) );
  }
  
  m_moduleID = helper->parentID(hits.front()->HitId());
  
  m_privateDigit = 0;

}

MooMdtSegment::MooMdtSegment	(std::vector<MooMdtHit*>& hits,
				 const double& alpha,
				 const double& Dalpha,
				 const double& beta,
				 const double& Dbeta,
				 const double& off_diagonal,
				 const double& Chi2,
				 const int&    nDegF,
				 const MdtIdHelper* helper)
  : MooRZSegment ( MooRZSegment(alpha, Dalpha, beta, Dbeta, off_diagonal, Chi2, nDegF) )
{
  // Set z and rho at the z of the 1st point
  m_z = (*(hits.begin()))->position().z();
  m_rho = m_tan_theta * m_z + m_beta;
  
  for (std::vector<MooMdtHit*>::const_iterator h = hits.begin(); h != hits.end(); ++h) {
    m_hits.push_back(new MooMdtHit(**h));
    m_multilayers.insert( helper->multilayer((*h)->digit()->identify()) );
  }
  
  m_moduleID = helper->parentID(hits.front()->HitId());

  m_privateDigit = 0;

}

MooMdtSegment::MooMdtSegment (const MooMdtSegment& seg)
  : MooRZSegment	( seg )
{
  for (std::vector<MooMdtHit*>::const_iterator h = seg.hits_cbegin(); h != seg.hits_cend(); ++h)
    m_hits.push_back(new MooMdtHit(**h));
  m_multilayers.insert ( seg.multilayers_begin(), seg.multilayers_end() );

  m_privateDigit = 0;

}

MooMdtSegment::~MooMdtSegment 	(void)
{
  for (std::vector<MooMdtHit*>::iterator h = m_hits.begin(); h != m_hits.end(); ++h) {
    if (m_privateDigit > 0) delete (*h)->digit();
    delete *h;
  }
}

void
MooMdtSegment::print_parameters	(void)
{
  std::cout << setiosflags(std::ios::fixed);
  std::cout << "      " << m_multilayers.size() << "-ml  MDTSeg: Z, Rho, cot(Th), Th, Chi2, Chi2/nDegF "
	    << std::setw(9) << std::setprecision(3) << m_z 	<< " "
	    << std::setw(9) << std::setprecision(3) << m_rho 	<< " "
	    << std::setw(6) << std::setprecision(3) << m_cot_theta << " "
	    << std::setw(6) << std::setprecision(3) << m_theta	<< " "
	    << std::setw(8) << std::setprecision(5) << m_Chi2 << " "
	    << std::setw(8) << std::setprecision(5) << m_Chi2/m_nDegF;
  std::cout << std::resetiosflags(std::ios::fixed)
	    << std::endl;
}

void
MooMdtSegment::print_hits	(const MdtIdHelper* helper)
{
  std::cout << "      i Det     Rho      Phi       Z       CotTh  DrT    DrD   Sig   Res     Identifier"
	    << std::endl;
  int i = 1;
  for (std::vector<MooMdtHit*>::const_iterator h = m_hits.begin(); h != m_hits.end(); ++i,++h) {
    std::cout << setiosflags(std::ios::fixed);
    std::cout << "    " << std::setw(3) << i << " " << helper->stationName( (*h)->digit()->identify() ) << " "
	      << std::setw(9) << std::setprecision(3) << (*h)->position().perp() << " "
	      << std::setw(7) << std::setprecision(3) << (*h)->phi2pi()        	    << " "
	      << std::setw(9) << std::setprecision(3) << (*h)->position().z()    << " "
	      << std::setw(8) << std::setprecision(3) << 1./tan((*h)->theta0pi())   << " "
	      << std::setw(5) << std::setprecision(1) << (*h)->digit()->tdc()    << " "
	      << std::setw(6) << std::setprecision(3) << (*h)->SignedDrift()     << " "
	      << std::setw(5) << std::setprecision(3) << (*h)->Error() 	    << " "
	      << std::setw(5) << std::setprecision(3) << (*h)->residual()        << " "
	      << helper->show_to_string( (*h)->HitId() );
    std::cout << std::resetiosflags(std::ios::fixed)
	      << std::endl;
  }
}

void
MooMdtSegment::print	(const MdtIdHelper* helper)
{
  print_parameters();
  print_hits( helper );
}

void MooMdtSegment::copyDigit ()
{
  m_privateDigit=1;
  for (std::vector<MooMdtHit*>::const_iterator h = hits_cbegin(); h != hits_cend(); ++h)
    (*h)->copyDigit();
}
