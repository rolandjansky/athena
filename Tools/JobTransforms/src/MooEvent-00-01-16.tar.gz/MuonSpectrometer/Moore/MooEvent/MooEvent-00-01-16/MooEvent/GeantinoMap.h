/***************************************************************************
 Class to read material and geantino step data from files, fill appropriate 
 map/vector structures, and provide tools to access the data.   
 -------------------------------------------
 Copyright (C) 2003 by ATLAS Collaboration
 ***************************************************************************/

#ifndef MOOEVENT_GEANTINOMAP_H
#define MOOEVENT_GEANTINOMAP_H



//<<<<<< INCLUDES                                                       >>>>>>

#include <vector>
#include <map>
#include <fstream>
#include <iostream>
#include <string>

// stringstreams working with gcc2.95 and gcc3.2 (cf. http://annwm.lbl.gov/~leggett/Atlas/gcc-3.2.html)
#ifdef HAVE_NEW_IOSTREAMS
  #include <sstream>
  typedef std::istringstream my_isstream;
#else
  #include <strstream>
  typedef strstream my_isstream;
#endif


//<<<<<< PUBLIC DEFINES                                                 >>>>>>
//<<<<<< PUBLIC CONSTANTS                                               >>>>>>
//<<<<<< PUBLIC TYPES                                                   >>>>>>

///----------------------------------------------------------------------------------------------------------------
///  A geantino step is an interval on a ray (0,infty), direction defined by (phi,theta), 
///  together with the traversed material. 
///----------------------------------------------------------------------------------------------------------------
struct GeantinoStep 
{
   double r;            // radial distance of point
   double X0Sum;        // total rad length traversed at end of step
   double aSum;         // ELoss slope at end of step
   double bSum;         // ELoss constant at end of step
};   



///----------------------------------------------------------------------------------------------------------------
/// There are three different kinds of detector sectors:
///
///  - 'standard sector' (-22.5 deg <= phi <= 22.5 deg)
///
///  - 'feet sector' (270 deg <= phi <= 337.5 deg)
///
///  - 'ECT service tower sector' (67.5 deg <= phi <= 112.5 deg; 
///     = 'standard sector' + EC Toroid service tower)
///
/// Due to symmetry the remaining parts are identical to 
/// 
///  - a standard sector (  22.5 deg <= phi <=  67.5 deg,
///                        112.5 deg <= phi <= 157.5 deg,
///                        157.5 deg <= phi <= 202.5 deg )
///
///  - a feet sector ( 202.5 deg <= phi <= 270 deg )  
///----------------------------------------------------------------------------------------------------------------
enum Sector { STANDARD, FEET, SERVICETOWER };



//<<<<<< PUBLIC VARIABLES                                               >>>>>>
//<<<<<< PUBLIC FUNCTIONS                                               >>>>>>
//<<<<<< CLASS DECLARATIONS                                             >>>>>>

class GeantinoMap
{
  public:
  
    /// GeantinoMap objects are constructed from a geantino map 
    GeantinoMap( std::string geantFileName);
    ~GeantinoMap();
    
    /// method to probe if geantino map file has been successfully opened
    bool isOpen();

    /// method to print out the first nLines lines of the geantino map file
    void printMap(int);
  
    /// method to retrieve the integrated 
    ///   - radiation length  
    ///   - energy-loss
    /// for the traversed distance rMax-rMin, a given ray defined by (phi, theta), 
    /// and a given track momentum p
    void totalRadLengthAndEnergyLoss( double&, double&, double, double, double, double, double);

    void radLengthAndEnergyLoss( double&, double&, double, double, double, double);
    
    bool containsPhi(double);
    bool containsTheta(double);

    /// method to determine the appropriate detector section
    //Sector getSector( double phi ) const;
  

  private:
  
    //-------------------------------------------------------------------------------------------------------------
    // private methods
    bool openFile( std::string fileName );
    bool closeFile();
  
    void readMap();
    bool insertGeantinoSteps( unsigned, unsigned, std::vector<GeantinoStep>* pStepVector );
    
    // methods to retrieve the bins/key for given phi and theta
    unsigned getPhiBin  ( double )   const;
    unsigned getPhiBin  ( unsigned )   const;
    unsigned getThetaBin( double ) const;
    unsigned getThetaBin( unsigned )   const;
    unsigned getKey( double, double)    const;
    unsigned getKey( unsigned, unsigned ) const;


    //-------------------------------------------------------------------------------------------------------------
    // private data members
    
    std::map< unsigned, std::vector<GeantinoStep> >  m_geantMap;
    typedef std::map< unsigned, std::vector<GeantinoStep> >::const_iterator  gMapIter;

    std::fstream* m_ioFile;

    bool m_readStatus;

    double m_phiStart, m_phiFinish, m_dPhi;          //angles in radians
    double m_thetaStart, m_thetaFinish, m_dTheta;

    double m_phiMin, m_phiMax, m_phiBinWidth;          
    double m_thetaMin, m_thetaMax, m_thetaBinWidth;

};



//<<<<<< INLINE PUBLIC FUNCTIONS                                        >>>>>>
//<<<<<< INLINE MEMBER FUNCTIONS                                        >>>>>>


#endif // MOOEVENT_GEANTINOMAP_H
