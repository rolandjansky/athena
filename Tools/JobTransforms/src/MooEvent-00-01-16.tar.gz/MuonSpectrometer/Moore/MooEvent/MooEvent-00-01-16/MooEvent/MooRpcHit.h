#ifndef MOOEVENT_MOORPCHIT_H
# define MOOEVENT_MOORPCHIT_H

#include "MooEvent/MooMuonHit.h"
#include "MuonDigitContainer/RpcDigit.h"
#include "MuonGeoModel/RpcReadoutElement.h"

class MooRpcHit: public MooMuonHit
{
public:

  MooRpcHit (std::vector<const RpcDigit*>& digits,
	     const HepPoint3D& position,
	     const MuonGM::RpcReadoutElement* chamber,
	     double error);
  MooRpcHit (const MooRpcHit& hit);
  ~MooRpcHit (void);
    
  std::vector<const RpcDigit*>::const_iterator	digits_begin	(void)	const;
  std::vector<const RpcDigit*>::const_iterator	digits_end	(void)	const;

  double Error (void)	const;
  
  Identifier	        HitId		(void)	const;

  const MuonGM::RpcReadoutElement*	detector_descriptor	(void)	const;
    
private:
  std::vector<const RpcDigit*>	    m_digits;
  Identifier			    m_id;
  const MuonGM::RpcReadoutElement*  m_descriptor;
  double                            m_error;
};

inline	std::vector<const RpcDigit*>::const_iterator
MooRpcHit::digits_begin	(void)	const
{ return m_digits.begin(); }

inline	std::vector<const RpcDigit*>::const_iterator
MooRpcHit::digits_end	(void)	const
{ return m_digits.end(); }

inline	Identifier
MooRpcHit::HitId	(void)	const
{ return m_id; }

inline	const MuonGM::RpcReadoutElement*
MooRpcHit::detector_descriptor	(void)	const
{ return m_descriptor; }

inline double
MooRpcHit::Error (void)	const
{ return m_error; }

#endif // MOOEVENT_MOORPCHIT_H
