#ifndef MOOEVENT_RZSEGMENTCOMBINATION_CONTAINER_H
#define MOOEVENT_RZSEGMENTCOMBINATION_CONTAINER_H

#include "DataModel/DataVector.h"
#include "CLIDSvc/CLASS_DEF.h"
#include "MooEvent/RZSegmentCombination.h"


class RZSegmentCombinationContainer: public DataVector<RZSegmentCombination>
{
 public:
  RZSegmentCombinationContainer (void);
  ~RZSegmentCombinationContainer (void);
};

inline
RZSegmentCombinationContainer::RZSegmentCombinationContainer (void)
  :DataVector<RZSegmentCombination>()
{}

inline
RZSegmentCombinationContainer::~RZSegmentCombinationContainer (void)
{}

CLASS_DEF( RZSegmentCombinationContainer , 1095886952 , 1 )





#endif // MOOEVENT_RZSEGMENTCOMBINATION_CONTAINER_H
