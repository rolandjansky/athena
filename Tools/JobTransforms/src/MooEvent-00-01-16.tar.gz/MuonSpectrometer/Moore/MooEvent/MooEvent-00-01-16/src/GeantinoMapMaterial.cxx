#include "MooEvent/GeantinoMapMaterial.h"
#include "PathResolver/PathResolver.h"
#include <cmath>
#include <iomanip>

GeantinoMapMaterial* GeantinoMapMaterial::s_myself = 0;



GeantinoMapMaterial::GeantinoMapMaterial( std::string filename )
{
  m_ioFile = 0;

  std::string fileName = PathResolver::find_file (filename, "DATAPATH");
  std::cout << "MooEvent/GeantinoMapMaterial constructor... " 
            << "\n... going to open file  "                   << fileName << std::endl;
  
  bool readStatus = openFile(fileName);
  if (readStatus)  readMap();
  else  std::cout << "... impossible to read from file  " << fileName << std::endl;
  
  closeFile();
}



GeantinoMapMaterial::~GeantinoMapMaterial()
{
  closeFile();
}



GeantinoMapMaterial* GeantinoMapMaterial::getGeantinoMapMaterial( std::string fileName ) 
{
  if ( s_myself == 0 ) 
  {
    std::cout << "MooEvent/GeantinoMapMaterial::getGeantinoMapMaterial:  " 
              << "Create the first/only instance of GeantinoMapMaterial" << std::endl;
    s_myself = new GeantinoMapMaterial(fileName);
  }

  return s_myself;
}



bool GeantinoMapMaterial::openFile( std::string fileName ) 
{
  if (fileName==" ") return false;
  std::cout << "MooEvent/GeantinoMapMaterial::openFileToRead: Open material file... " << std::endl;
  if ( m_ioFile == 0 )  
  {
    std::cout << "... m_ioFile = 0: Open the material file  " << fileName << std::endl;
    m_ioFile = new std::fstream( fileName.c_str(), std::ios::in );  // open file to read material properties
    return true;
  } 
  else 
  {
    return false;
  }
}



bool GeantinoMapMaterial::closeFile() 
{
  if (m_ioFile) 
  {
    m_ioFile->close();  // close file containing material properties
    m_ioFile = 0;
    return true;
  }
  else
  {
    std::cout << "MooEvent/GeantinoMapMaterial::closeFile: Trying to close a material file never opened!" 
              << std::endl;
    return false;
  } 
}



bool GeantinoMapMaterial::insertMaterial( unsigned matID, MaterialProperties matProp )
{
  matMapIter mit = m_matMap.find(matID);
  if ( mit == m_matMap.end() )    // no entry yet
  {
    m_matMap[matID] = matProp;
    return true;
  }
  else
  {
    std::cout << "MooEvent/GeantinoMapMaterial::insertMaterial: DOUBLE key detected!" << std::endl;
    return false;    
  }
}



double GeantinoMapMaterial::getRadLength( unsigned matID ) 
{
  matMapIter mit = m_matMap.find(matID);
  if ( mit != m_matMap.end() )            // found appropriate entry
  {
    return m_matMap[matID].radLength;
  }
  else
  {
    std::cout << "MooEvent/GeantinoMapMaterial::getRadLength: Material (matID = " << matID << ") not known!" 
              << std::endl;
    return 9.0E99;  // 'infinity'    
  }
}



double GeantinoMapMaterial::getAEloss( unsigned matID ) 
{
  matMapIter mit = m_matMap.find(matID);
  if ( mit != m_matMap.end() )            // found appropriate entry
  {
    return m_matMap[matID].aEloss;
  }
  else
  {
    std::cout << "MooEvent/GeantinoMapMaterial::getRadLength: Material (matID = " << matID << ") not known!" 
              << std::endl;
    return 0;      
  }
}



double GeantinoMapMaterial::getBEloss( unsigned matID ) 
{
  matMapIter mit = m_matMap.find(matID);
  if ( mit != m_matMap.end() )            // found appropriate entry
  {
    return m_matMap[matID].bEloss;
  }
  else
  {
    std::cout << "MooEvent/GeantinoMapMaterial::getRadLength: Material (matID = " << matID << ") not known!" 
              << std::endl;
    return 0;      
  }
}



void GeantinoMapMaterial::setRadLength( unsigned matID, double rl ) 
{
  matMapIter mit = m_matMap.find(matID);
  if ( mit != m_matMap.end() )           // found existing entry
  {
    m_matMap[matID].radLength = rl;      // modify existing value
  }
  else                                   // no entry yet 
  {
    MaterialProperties matProp;          // enter into materials map
    matProp.radLength = rl;
    insertMaterial( matID, matProp );
  }
}



void GeantinoMapMaterial::setAEloss( unsigned matID, double a ) 
{
  matMapIter mit = m_matMap.find(matID);
  if ( mit != m_matMap.end() )           // found existing entry
  {
    m_matMap[matID].aEloss = a;          // modify existing value
  }
  else                                   // no entry yet 
  {
    MaterialProperties matProp;          // enter into materials map
    matProp.aEloss = a;
    insertMaterial( matID, matProp );
  }
}



void GeantinoMapMaterial::setBEloss( unsigned matID, double b ) 
{
  matMapIter mit = m_matMap.find(matID);
  if ( mit != m_matMap.end() )           // found existing entry
  {
    m_matMap[matID].bEloss = b;          // modify existing value
  }
  else                                   // no entry yet 
  {
    MaterialProperties matProp;          // enter into materials map
    matProp.bEloss = b;
    insertMaterial( matID, matProp );
  }
}



void GeantinoMapMaterial::readMap() 
{
  std::string s;
  int nEntries = 0;
  
  while ( getline( *m_ioFile, s ) )
  {
    unsigned matID;
    MaterialProperties matProp;

    my_isstream istrvar( s.c_str() );

    istrvar >> matID >> matProp.radLength >> matProp.aEloss >> matProp.bEloss;
    insertMaterial( matID, matProp );
    nEntries++;
  }
  
  std::cout << "MooEvent/GeantinoMapMaterial::readMap: " << nEntries 
            << " entries read from material properties file"
            << std::endl;
}



void GeantinoMapMaterial::printMap() 
{
  std::cout << "MooEvent/GeantinoMapMaterial::printMap: Printout of material map..." << std::endl;
  std::cout << "   ID" << "    radLength" << "       aEloss" << "       bEloss" << std::endl;     // header
  for ( matMapIter mit = m_matMap.begin(); mit != m_matMap.end(); mit++ )
  {
     unsigned matID = mit->first;
     std::cout.width(5);
     std::cout << matID;   
     std::cout.width(13); std::cout.precision(4); std::cout.setf( std::ios::fixed, std::ios::floatfield );
     std::cout << m_matMap[matID].radLength;
     std::cout.width(13); std::cout.precision(3); std::cout.setf( std::ios::scientific, std::ios::floatfield );
     std::cout << m_matMap[matID].aEloss; 
     std::cout.width(13); std::cout.precision(3); std::cout.setf( std::ios::scientific, std::ios::floatfield );
     std::cout << m_matMap[matID].bEloss; 
     std::cout << std::endl;
  }  
  std::cout << "MooEvent/GeantinoMapMaterial::printMap: End printout of material map..." << std::endl;
}
