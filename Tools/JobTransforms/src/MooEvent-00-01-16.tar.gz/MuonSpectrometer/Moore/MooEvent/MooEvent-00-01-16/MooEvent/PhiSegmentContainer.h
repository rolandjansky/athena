#ifndef MOOEVENT_PHI_SEGMENT_CONTAINER_H
# define MOOEVENT_PHI_SEGMENT_CONTAINER_H

#include "DataModel/DataVector.h"
#include "CLIDSvc/CLASS_DEF.h"
#include "MooEvent/PhiSegment.h"

class PhiSegmentContainer: public DataVector<PhiSegment>
{
public:
  PhiSegmentContainer (void);
  ~PhiSegmentContainer (void);
};

inline
PhiSegmentContainer::PhiSegmentContainer (void)
  :	DataVector<PhiSegment>	()
{}

inline
PhiSegmentContainer::~PhiSegmentContainer (void)
{}

CLASS_DEF(PhiSegmentContainer, 4045, 1)

#endif // MOOEVENT_PHI_SEGMENT_CONTAINER_H
