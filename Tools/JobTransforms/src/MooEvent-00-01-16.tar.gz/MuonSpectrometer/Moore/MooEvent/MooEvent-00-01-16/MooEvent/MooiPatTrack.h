#ifndef MOOEVENT_MOOIPATTRACK_H
# define MOOEVENT_MOOIPATTRACK_H

// #include <vector>
#include <set>
#include <string>

#include "iPatTrack/Track.h"

class MuonIdHelper;

class MooiPatTrack:public Track
{
public:
  MooiPatTrack (void);
  MooiPatTrack (const MooiPatTrack&); // Copy constructor
  MooiPatTrack( std::string muon_status,
	        std::list<HitOnTrack*>&  hits,
		std::set<unsigned>&      station_layers,
		std::set<unsigned>&	 phi_layers,
		int&                     mdt_hits,
		int&                     csc_hits,
		int&                     rpc_hits,
		int&                     tgc_hits,
		int&                     phi_hits,
		PerigeeParameters*     	 perigee,
		FitQuality*              fit_quality,
		HitQuality*              hit_quality);
  MooiPatTrack( std::string muon_status,
	        std::list<HitOnTrack*>&  hits,
		std::set<unsigned>&      station_layers,
		std::set<unsigned>&	 phi_layers,
		int&                     mdt_hits,
		int&                     csc_hits,
		int&                     rpc_hits,
		int&                     tgc_hits,
		int&                     phi_hits,
		PerigeeParameters*     	 perigee,
		FitQuality*              fit_quality,
		HitQuality*              hit_quality,
		parameter_vector&        sc_params);
    
  void	print		       	(const MuonIdHelper* helper);
  void	print_muon_parameters  	(void);
  void	print_muon_hits	       	(const MuonIdHelper* helper);
  void	print_muon_hits_summary	(void);
    
  unsigned                              station_layers_count  	(void)	const;
  std::set< unsigned>::const_iterator	station_layers_begin  	(void)	const;
  std::set< unsigned>::const_iterator	station_layers_end	(void)	const;
  std::set< unsigned>::const_iterator	phi_layers_begin	(void)	const;
  std::set< unsigned>::const_iterator	phi_layers_end	       	(void)	const;

  int  mdt_hits_count        (void)	const;
  int  csc_hits_count        (void)	const;
  int  precision_hits_count  (void)	const;
  int  rpc_hits_count        (void)	const;
  int  tgc_hits_count        (void)	const;
  int  phi_hits_count        (void)	const;

  std::string  muon_status (void)	const;
  void	       muon_status (std::string);

private:

  std::string         m_muon_status;
  std::set<unsigned>  m_station_layers;
  std::set<unsigned>  m_phi_layers;

  int                 m_mdt_hits_count;
  int                 m_csc_hits_count;
  int                 m_rpc_hits_count;
  int                 m_tgc_hits_count;
  int                 m_phi_hits_count;
  
};

inline unsigned
MooiPatTrack::station_layers_count	(void)	const
{ return m_station_layers.size(); }

inline	std::set< unsigned >::const_iterator
MooiPatTrack::station_layers_begin     	(void)	const
{ return m_station_layers.begin(); }

inline	std::set< unsigned >::const_iterator
MooiPatTrack::station_layers_end       	(void)	const
{ return m_station_layers.end(); }

inline	std::set< unsigned >::const_iterator
MooiPatTrack::phi_layers_begin		(void)	const
{ return m_phi_layers.begin(); }

inline	std::set< unsigned >::const_iterator
MooiPatTrack::phi_layers_end		(void)	const
{ return m_phi_layers.end(); }

inline std::string
MooiPatTrack::muon_status	(void)	const
{ return m_muon_status; }

inline void
MooiPatTrack::muon_status	(std::string status)
{
  std::string::size_type	pos	=	m_muon_status.find(status);
  if (pos == std::string::npos) {
    std::string::size_type 	posr	=	m_muon_status.find("road_");
    std::string::size_type 	posf	=	m_muon_status.find("final_");
    std::string::size_type 	posm	=	m_muon_status.find("mat_");
    std::string::size_type 	statr	=	status.find("road_");
    std::string::size_type 	statf	=	status.find("final_");
    std::string::size_type 	statm	=	status.find("mat_");
    if (posr != std::string::npos && statr != std::string::npos) { // status = road_*, track = road_*
      m_muon_status.replace(posr, posr+9, status);
    } else if (posf != std::string::npos && statf != std::string::npos) { // status = final_*, track = final_*
      m_muon_status.replace(posf, posf+10, status);
    } else if (posm != std::string::npos && statm != std::string::npos) { // status = mat_*, track = mat_*
      m_muon_status.replace(posm, posm+8, status);
    } else {
      m_muon_status.append(":").append(status);
    }
  }
}

inline int
MooiPatTrack::mdt_hits_count  (void)	const
{ return m_mdt_hits_count; }

inline int
MooiPatTrack::csc_hits_count  (void)	const
{ return m_csc_hits_count; }

inline int
MooiPatTrack::precision_hits_count  (void)	const
{ return m_csc_hits_count + m_mdt_hits_count; }

inline int
MooiPatTrack::rpc_hits_count  (void)	const
{ return m_rpc_hits_count; }

inline int
MooiPatTrack::tgc_hits_count  (void)	const
{ return m_tgc_hits_count; }

inline int
MooiPatTrack::phi_hits_count  (void)	const
{ return m_phi_hits_count; }

#endif // MOOEVENT_MOOIPATTRACK_H
