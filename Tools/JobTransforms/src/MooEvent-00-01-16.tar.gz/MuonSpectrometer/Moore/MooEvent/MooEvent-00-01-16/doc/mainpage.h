/**

@mainpage The MooEvent package

@section introMooEvent Introduction

MooEvent is a sub-package of the Moore package.
It is intended to contain Moore event data classes
used during the pattern recognition and fitting stages of
the muon reconstruction inside the Muon Spectrometer.

@section MooEventSoft Software

Moore relies on the following event data classes contained
in this package:
MooMuonHit and derived technology-specific hit classes,
PhiSegment, MooCscSegment, MooMdtSegment, MooRZSegment,
RZSegmentCombination, MooiPatTrack, and various container
classes.

@section ExtrasMooEvent Extra Pages

  - @ref used_MooEvent
  - @ref requirements_MooEvent

*/

/**
@page used_MooEvent Used Packages
@htmlinclude used_packages.html
*/

/**
@page requirements_MooEvent Requirements
@include requirements
*/
