#include "MooEvent/MooCscHit.h"

MooCscHit::~MooCscHit (void)
{}

MooCscHit::MooCscHit	(CscCluster* cluster,
			 const MuonGM::CscReadoutElement* chamber)
  :	MooMuonHit	(cluster->position(), chamber->globalPosition()),
	m_cluster	( cluster ),
	m_id            ( cluster->identify() ),
	m_descriptor	( chamber )
{
  if (m_descriptor->getStationS() != 0.) {
    m_T = sqrt(m_T*m_T-m_descriptor->getStationS()*m_descriptor->getStationS());
  } 
}

MooCscHit::MooCscHit	(MooCscHit& hit)
  :	MooMuonHit	( MooMuonHit(hit) ),
	m_cluster      	( hit.cluster() ),
	m_id		( hit.HitId() ),
	m_descriptor	( hit.detector_descriptor() )
{}

