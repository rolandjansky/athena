#ifndef MOOEVENT_MOOMDTHIT_H
# define MOOEVENT_MOOMDTHIT_H

#include "MooEvent/MooMuonHit.h"
#include "MuonDigitContainer/MdtDigit.h"
#include "MuonGeoModel/MdtReadoutElement.h"

class MooMdtHit: public MooMuonHit
{
public:
  MooMdtHit (const MdtDigit* digit,
	     const HepPoint3D& position,
	     const MuonGM::MdtReadoutElement* chamber,
	     double error_tube);
  MooMdtHit (const MooMdtHit& hit);
  ~MooMdtHit (void);

  // Get methods
  const MdtDigit*			digit			(void)	const;
  Identifier			        HitId			(void)	const;
  double			        SignedDrift		(void)	const;
  double			        Error		        (void)	const;
  double			        ErrorTube		(void)	const;
  double		                residual                (void)  const;
  double                                DriftTimeCorrected      (void)  const;
  double                                SecondCoordinate        (void)  const;
  const MuonGM::MdtReadoutElement*	detector_descriptor	(void)	const;
    
  // Set methods
  void 	SignedDrift  (double drift);
  void 	Error	     (double error);
  void	residual     (double residual);
  void  DriftTimeCorrected (double time);
  void  SecondCoordinate (double x);
    
  // For Rome Calib Algs
  void copyDigit ();  // creates a new copy of MdtDigit.
                      // This method is designed to be used by MooMdtSegment only.
                      // Memory management is user responsability.

private:
  const MdtDigit*			m_digit;
  double			        m_signed_drift;
  double			        m_error_drift;
  double			        m_error_tube;
  double		                m_residual;
  double                                m_drift_time_corrected;
  double                                m_second_coordinate;
  const MuonGM::MdtReadoutElement*   	m_descriptor;
    
};

inline	const MdtDigit*
MooMdtHit::digit	(void)	const
{ return m_digit; }

inline	Identifier
MooMdtHit::HitId	(void)	const
{ return m_digit->identify(); }

inline	double
MooMdtHit::SignedDrift	(void)	const
{ return m_signed_drift; }

inline	double
MooMdtHit::Error	(void)	const
{ return m_error_drift; }

inline	double
MooMdtHit::ErrorTube	(void)	const
{ return m_error_tube; }

inline double
MooMdtHit::residual (void) const
{ return m_residual; }

inline double
MooMdtHit::DriftTimeCorrected (void) const
{ return m_drift_time_corrected; }

inline double
MooMdtHit::SecondCoordinate (void) const
{ return m_second_coordinate; }

inline	void
MooMdtHit::SignedDrift	(double drift)
{ m_signed_drift = drift; }

inline	void
MooMdtHit::Error	(double error)
{ m_error_drift = error; }

inline	const MuonGM::MdtReadoutElement*
MooMdtHit::detector_descriptor	(void)	const
{ return m_descriptor; }

inline void
MooMdtHit::residual (double value)
{ m_residual = value; }

inline void
MooMdtHit::DriftTimeCorrected (double value)
{ m_drift_time_corrected = value; }

inline void
MooMdtHit::SecondCoordinate (double value)
{ m_second_coordinate = value; }

#endif // MOOEVENT_MOOMDTHIT_H
