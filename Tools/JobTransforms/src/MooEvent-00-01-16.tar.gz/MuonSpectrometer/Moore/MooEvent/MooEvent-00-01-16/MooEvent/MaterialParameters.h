#ifndef MOOEVENT_MATERIALPARAMETERS_H
#define MOOEVENT_MATERIALPARAMETERS_H

class MaterialParameters{
public:
  MaterialParameters();
  MaterialParameters(int, double, double, double, double, double, double );

  // selectors
  int    nEvents() const;
  double thickness() const;
  double sigmaThickness() const;
  double eloss0() const;
  double eloss1() const;
  double sigmaEloss0() const;
  double sigmaEloss1() const;
  // modifiers
  void    nEvents(int);
  void thickness(double);
  void sigmaThickness(double);
  void eloss0(double);
  void eloss1(double);
  void sigmaEloss0(double);
  void sigmaEloss1(double);
// input/output operator
  friend std::ostream & operator<<(std::ostream & os, const MaterialParameters & MP);
  friend std::istream & operator>>(std::istream & is, MaterialParameters & MP);

private:
  int    _nevents;
  double _thickness;
  double _sigmaThickness;
  double _eloss0;
  double _eloss1;
  double _sigmaEloss0;
  double _sigmaEloss1;
};
#endif
