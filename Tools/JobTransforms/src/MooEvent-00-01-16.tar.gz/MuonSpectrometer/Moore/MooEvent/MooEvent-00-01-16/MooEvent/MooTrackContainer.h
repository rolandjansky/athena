#ifndef MOOEVENT_MOOTRACKCONTAINER_H
# define MOOEVENT_MOOTRACKCONTAINER_H

#include "DataModel/DataVector.h"
#include "CLIDSvc/CLASS_DEF.h"
#include "MooEvent/MooiPatTrack.h"

class MooTrackContainer: public DataVector<MooiPatTrack>
{
public:
  MooTrackContainer (void);
  ~MooTrackContainer (void);
};

inline
MooTrackContainer::MooTrackContainer (void)
  :	DataVector<MooiPatTrack>   ()
{}

inline
MooTrackContainer::~MooTrackContainer (void)
{}

CLASS_DEF(MooTrackContainer, 4049, 1)

#endif // MOOEVENT_MOOTRACKCONTAINER_H
