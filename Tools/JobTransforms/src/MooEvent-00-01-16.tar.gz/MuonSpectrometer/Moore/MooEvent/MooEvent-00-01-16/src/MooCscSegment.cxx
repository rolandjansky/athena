#include <iomanip>
#include <iostream>

#include "MooEvent/MooCscSegment.h"

MooCscSegment::MooCscSegment 	(std::vector<MooCscHit*>& hits, const CscIdHelper* helper)
  :	MooRZSegment	 ( MooRZSegment() )
{
  for (std::vector<MooCscHit*>::const_iterator h = hits.begin(); h != hits.end(); ++h)
    m_hits.push_back(new MooCscHit(**h));
  
  m_moduleID = helper->parentID(hits.front()->HitId());

}

MooCscSegment::MooCscSegment 	(std::vector<MooCscHit*>& hits,
				 double z,
				 double rho,
				 double theta,
				 double Chi2,
				 const CscIdHelper* helper)
  : MooRZSegment        ( MooRZSegment(z, rho, theta) )
{
  m_Chi2 = Chi2;
  for (std::vector<MooCscHit*>::const_iterator h = hits.begin(); h != hits.end(); ++h)
    m_hits.push_back(new MooCscHit(**h));

  m_moduleID = helper->parentID(hits.front()->HitId());

}

MooCscSegment::MooCscSegment (const MooCscSegment& seg)
  : MooRZSegment	( MooRZSegment(seg) )
{
  for (std::vector<MooCscHit*>::const_iterator h = seg.hits_cbegin(); h != seg.hits_cend(); ++h)
    m_hits.push_back(new MooCscHit(**h));
}

MooCscSegment::~MooCscSegment 	(void)
{
  for (std::vector<MooCscHit*>::iterator h = m_hits.begin(); h != m_hits.end(); ++h)
    delete *h;
}

void
MooCscSegment::print_parameters	(void)
{
  std::cout << std::setiosflags(std::ios::fixed);
  std::cout << "      CSCSeg: Z, Rho, cot(Th), Th, RS "
	    << std::setw(9) << std::setprecision(3) << m_z 	<< " "
	    << std::setw(9) << std::setprecision(3) << m_rho 	<< " "
	    << std::setw(6) << std::setprecision(3) << m_cot_theta << " "
	    << std::setw(6) << std::setprecision(3) << m_theta	<< " "
	    << std::setw(8) << std::setprecision(5) << m_Chi2;
  std::cout << std::resetiosflags(std::ios::fixed)
	    << std::endl;
}

void
MooCscSegment::print_hits	(const CscIdHelper* helper)
{
  std::cout << "      i Det     Rho      Phi       Z      Theta      Identifier"
	    << std::endl;
  int i = 1;
  for (std::vector<MooCscHit*>::const_iterator h = m_hits.begin(); h != m_hits.end(); ++i,++h) {
    std::cout << std::setiosflags(std::ios::fixed);
    std::cout << "    " << std::setw(3) << i << helper->stationName( (*h)->cluster()->identify() ) << " "
	      << std::setw(9) << std::setprecision(3) << (*h)->position().perp() << " "
	      << std::setw(7) << std::setprecision(3) << (*h)->phi2pi()     	    << " "
	      << std::setw(8) << std::setprecision(3) << (*h)->position().z()    << " "
	      << std::setw(7) << std::setprecision(4) << (*h)->theta0pi()	    << " "
	      << helper->show_to_string( (*h)->HitId() );
    std::cout << std::resetiosflags(std::ios::fixed)
	      << std::endl;
  }
}

void
MooCscSegment::print	(const CscIdHelper* helper)
{
  print_parameters();
  print_hits(helper);
}
