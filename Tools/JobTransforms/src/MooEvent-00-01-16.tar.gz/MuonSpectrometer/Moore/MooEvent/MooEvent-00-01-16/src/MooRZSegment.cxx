#include <math.h>
#include "MooEvent/MooRZSegment.h"

MooRZSegment::MooRZSegment (void)
  : m_z		    ( 0. ),
    m_rho	    ( 0. ),
    m_beta	    ( 0. ),
    m_beta_error    ( 0. ),
    m_theta	    ( 0. ),
    m_theta_error   ( 0. ),
    m_off_diagonal  ( 0. ),
    m_Chi2          ( 0. ),
    m_nDegF         ( -1 ),
    m_tan_theta	    ( 0. ),
    m_cot_theta	    ( 10000. )
{}

MooRZSegment::MooRZSegment (double z, double rho, double theta)
  : m_z		    ( z ),
    m_rho	    ( rho ),
    m_beta	    ( 0. ),
    m_beta_error    ( 0. ),
    m_theta    	    ( theta ),
    m_theta_error   ( 0. ),
    m_off_diagonal  ( 0. ),
    m_Chi2          ( 0. ),
    m_nDegF         ( -1 ),
    m_tan_theta	    ( tan(theta) )
{ m_cot_theta = 1./m_tan_theta; }

MooRZSegment::MooRZSegment	(const double& alpha,
				 const double& Dalpha,
				 const double& beta,
				 const double& Dbeta,
				 const double& off_diagonal,
				 const double& Chi2,
				 const int&    nDegF)
  : m_z		    ( 0. ),
    m_rho	    ( beta ),
    m_beta	    ( beta ),
    m_beta_error    ( Dbeta ),
    m_theta    	    ( alpha ),
    m_theta_error   ( Dalpha ),
    m_off_diagonal  ( off_diagonal ),
    m_Chi2          ( Chi2 ),
    m_nDegF         ( nDegF )
{
  if (m_theta < 0.) m_theta += M_PI;
  m_tan_theta   = tan(m_theta);
  m_cot_theta   = 1./m_tan_theta;
}

MooRZSegment::MooRZSegment (const MooRZSegment& seg)
  : m_z		    ( seg.z() ),
    m_rho	    ( seg.rho() ),
    m_beta	    ( seg.beta() ),
    m_beta_error    ( seg.beta_error() ),
    m_theta    	    ( seg.theta() ),
    m_theta_error   ( seg.theta_error() ),
    m_off_diagonal  ( seg.off_diagonal() ),
    m_Chi2          ( seg.Chi2() ),
    m_nDegF         ( seg.nDegF() ),
    m_tan_theta	    ( seg.tan_theta() ),
    m_cot_theta	    ( seg.cot_theta() ),
    m_moduleID      ( seg.identify_module() )
{}

MooRZSegment::~MooRZSegment (void)
{}

const HepPoint3D&
MooRZSegment::detector_position  	(void)	const
{ return HepPoint3D(0., 0., 0.); }

unsigned
MooRZSegment::hits_count (void) const
{ return 0; }
