#ifndef MOOEVENT_MDTSEGMENTCONTAINER
#define MOOEVENT_MDTSEGMENTCONTAINER

#include "DataModel/DataVector.h"
#include "CLIDSvc/CLASS_DEF.h"
#include "MooEvent/MooMdtSegment.h"

class MdtSegmentContainer : public DataVector<MooMdtSegment>
{
 public:
  MdtSegmentContainer();
  ~MdtSegmentContainer();

};

inline MdtSegmentContainer::MdtSegmentContainer():
  DataVector<MooMdtSegment>()
{ } 

inline MdtSegmentContainer::~MdtSegmentContainer()
{ } 


CLASS_DEF(MdtSegmentContainer, 4077, 1)
#endif  // MOOEVENT_MDTSEGMENTCONTAINER
