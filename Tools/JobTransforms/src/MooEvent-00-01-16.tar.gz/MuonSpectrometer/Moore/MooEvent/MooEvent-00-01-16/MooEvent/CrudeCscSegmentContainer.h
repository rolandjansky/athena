#ifndef MOOEVENT_CRUDE_CSCSEGMENT_CONTAINER_H
# define MOOEVENT_CRUDE_CSCSEGMENT_CONTAINER_H

#include "DataModel/DataVector.h"
#include "CLIDSvc/CLASS_DEF.h"
#include "MooEvent/MooCscSegment.h"

class CrudeCscSegmentContainer: public DataVector<MooCscSegment>
{
public:
  CrudeCscSegmentContainer (void);
  ~CrudeCscSegmentContainer (void);
};

inline
CrudeCscSegmentContainer::CrudeCscSegmentContainer (void)
  :	DataVector<MooCscSegment>	()
{}

inline
CrudeCscSegmentContainer::~CrudeCscSegmentContainer (void)
{}

CLASS_DEF(CrudeCscSegmentContainer, 4047, 1)

#endif // MOOEVENT_CRUDE_CSCSEGMENT_CONTAINER_H
