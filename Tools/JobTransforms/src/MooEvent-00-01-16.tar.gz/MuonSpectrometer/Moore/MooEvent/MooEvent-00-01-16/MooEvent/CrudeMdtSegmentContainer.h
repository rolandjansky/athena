#ifndef MOOEVENT_CRUDE_MDTSEGMENT_CONTAINER_H
# define MOOEVENT_CRUDE_MDTSEGMENT_CONTAINER_H

#include "DataModel/DataVector.h"
#include "CLIDSvc/CLASS_DEF.h"
#include "MooEvent/MooMdtSegment.h"

class CrudeMdtSegmentContainer: public DataVector<MooMdtSegment>
{
public:
  CrudeMdtSegmentContainer (void);
  ~CrudeMdtSegmentContainer (void);
};

inline
CrudeMdtSegmentContainer::CrudeMdtSegmentContainer (void)
  :	DataVector<MooMdtSegment>	()
{}

inline
CrudeMdtSegmentContainer::~CrudeMdtSegmentContainer (void)
{}

CLASS_DEF(CrudeMdtSegmentContainer, 4046, 1)

#endif // MOOEVENT_CRUDE_MDTSEGMENT_CONTAINER_H
