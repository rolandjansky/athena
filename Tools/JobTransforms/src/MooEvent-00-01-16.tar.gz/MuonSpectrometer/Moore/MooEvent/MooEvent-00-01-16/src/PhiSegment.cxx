#include <iomanip>
#include <iostream>
#include <math.h>

#include "Identifier/Identifier.h"
#include "MuonIdHelpers/MuonIdHelper.h"

#include "MooEvent/MooRpcHit.h"
#include "MooEvent/MooTgcHit.h"
#include "MooEvent/MooCscHit.h"
#include "MooEvent/MooMdtHit.h"
#include "MooEvent/PhiSegment.h"

PhiSegment::PhiSegment (void)
{}

PhiSegment::PhiSegment (std::vector<MooMuonHit*>&      	digits,
			std::vector<Identifier>&	detectors,
			double&				phi)
  :	m_detectors		( detectors ),
	m_phi			( phi )
{
  for (std::vector<MooMuonHit*>::const_iterator h = digits.begin(); h != digits.end(); ++h) {
    MooRpcHit*	rhit = dynamic_cast<MooRpcHit*>(*h);
    if (rhit) {
      m_hits.push_back(new MooRpcHit(*rhit));
    } else {
      MooTgcHit* thit = dynamic_cast<MooTgcHit*>(*h);
      if (thit) {
	m_hits.push_back(new MooTgcHit(*thit));
      } else {
	MooCscHit* chit = dynamic_cast<MooCscHit*>(*h);
	if (chit) {
           m_hits.push_back(new MooCscHit(*chit));
        } else {
	  MooMdtHit* mhit = dynamic_cast<MooMdtHit*>(*h);
	  if (mhit) {
             m_hits.push_back(new MooMdtHit(*mhit));
	  }
	}
      }
    }
  }
}

PhiSegment::~PhiSegment (void)	
{ for (std::vector<MooMuonHit*>::iterator h = m_hits.begin(); h != m_hits.end(); ++h) delete *h; }

void
PhiSegment::print	(const MuonIdHelper* helper) const
{
  std::cout << "      Phi-Segment has " << m_hits.size() << " digits. Average Phi = ";
  std::cout << std::setiosflags(std::ios::fixed) << std::setw(6) << std::setprecision(3)
	    << m_phi << std::resetiosflags(std::ios::fixed) << std::endl;
  std::cout << "      ------------------------------------------" << std::endl;
  std::cout << "            Rho     Phi      Z        Time      DetName    Identifier" << std::endl;
		
    for (std::vector<MooMuonHit*>::const_iterator h = m_hits.begin(); h != m_hits.end(); ++h) {

      std::cout << std::setiosflags(std::ios::fixed);
      std::cout << std::setprecision(3);
      std::cout << "         "
		<< std::setw(8) << (*h)->position().perp() << " " 
		<< std::setw(6) << (*h)->phi2pi() << " " 
		<< std::setw(8) << (*h)->position().z() << " ";

      Identifier      channelId;
      std::string DetName;
      MooRpcHit*	rhit = dynamic_cast<MooRpcHit*>(*h);
      if (rhit) {
	channelId = rhit->HitId();
	const int st_index   = helper->stationName(channelId);
	DetName = helper->stationNameString(st_index);
	std::cout << std::setw(8) << (*(rhit->digits_begin()))->time() << "    "
		  << std::setw(6) << DetName << "   "
		  << helper->show_to_string(channelId);
      } else {
	MooTgcHit*	thit = dynamic_cast<MooTgcHit*>(*h);
	if (thit) {
	  channelId = thit->HitId();
	  const int st_index   = helper->stationName(channelId);
	  DetName = helper->stationNameString(st_index);
	  std::cout << "        "
		    << std::setw(6) << DetName << " "
		    << helper->show_to_string(channelId);
	} else {
	  MooCscHit*	chit = dynamic_cast<MooCscHit*>(*h);
	  if (chit) {
	    channelId = chit->HitId();
	    const int st_index   = helper->stationName(channelId);
	    DetName = helper->stationNameString(st_index);
	    std::cout << "        "
		      << std::setw(6) << DetName << " "
		      << helper->show_to_string(channelId);
	  }
	}
      }
	
      std::cout << std::resetiosflags(std::ios::fixed)
		<< std::endl;
    }
}


